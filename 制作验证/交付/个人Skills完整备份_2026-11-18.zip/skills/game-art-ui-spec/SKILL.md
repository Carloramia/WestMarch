---
name: game-art-ui-spec
description: Write game-art briefs or game-interface specifications with visual intent, asset constraints, interaction states and acceptance criteria. Use for art and UI production handoffs, not generating images, implementing a web app or automatically redesigning supplied art.
---

# Game Art and UI Specification

Select the handoff the user needs; do not merge art composition and interaction logic into an undifferentiated brief.

- Character, environment, prop or illustration requirements: [art brief specification](references/art-requirement/references/spec.json).
- Screens, controls, states, navigation and data contracts: [UI specification](references/ui-spec/references/spec.json).

## Shared Requirements

1. Start from the provided subject, audience, use context, source references and existing style or interface system.
2. Separate approved requirements, visual references, optional proposals and unresolved decisions. References are not automatic authorization to copy protected work.
3. For art, specify readable silhouette, focal hierarchy, composition, material/style and asset technical constraints only at the detail needed for production.
4. For UI, specify primary tasks, information hierarchy, control states, empty/loading/error behavior, navigation and responsive constraints.
5. Keep measurable acceptance criteria and handoff formats tied to actual usage. Do not invent resolutions, platforms, asset budgets or animation counts.

Generate only the requested brief or specification. Actual image creation, source-image edits and interface implementation use their appropriate tools and separate workflows.
