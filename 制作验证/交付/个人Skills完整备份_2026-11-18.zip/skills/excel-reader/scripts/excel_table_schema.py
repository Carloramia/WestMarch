#!/usr/bin/env python3
"""
excel_table_schema.py  —  Sub-Table Schema Extractor

一个 Excel Sheet 里往往有多张语义独立的子表（用空行 / 标题行 / 颜色分隔）。
本脚本检测这些子表边界，提取每个子表的列头，建立

    cell → (子表, 列语义名, 相对行号)

的映射，供公式语义化解析使用。

用法:
    python excel_table_schema.py <excel_path> --tag <tag> [--sheets "S1" "S2"]
    python excel_table_schema.py <excel_path> --tag <tag> --all-sheets

输出:
    {tag}_export/sheet_NN_data/table_schema.json   每个 Sheet 的子表 schema
    {tag}_export/table_schema_summary.md            人类可读摘要
"""

import openpyxl
from openpyxl.utils import get_column_letter, column_index_from_string
import json, os, re, argparse
from pathlib import Path
from datetime import datetime


# ─────────────────────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────────────────────

def parse_cell_ref(ref: str):
    """'F45' 或 '$F$45' → (col_letter, row_int)，失败返回 (None, None)"""
    clean = ref.replace('$', '').strip()
    m = re.match(r'^([A-Za-z]+)(\d+)$', clean)
    if m:
        return m.group(1).upper(), int(m.group(2))
    return None, None


def extract_refs_from_formula(formula: str):
    """从公式字符串中提取所有单元格引用（含绝对引用）"""
    if not formula:
        return []
    return re.findall(r'\$?[A-Z]+\$?\d+', formula)


def col_letter_to_idx(col: str) -> int:
    try:
        return column_index_from_string(col)
    except Exception:
        return 0


# ─────────────────────────────────────────────────────────────
# 隐藏行/列工具（与隐藏 Sheet 逻辑对称）
# ─────────────────────────────────────────────────────────────

def _build_hidden_sets(ws) -> tuple:
    """
    返回 (hidden_rows: set[int], hidden_cols: set[int])
    隐藏行/列的编号集合（1-based）。
    与 sheet_state 过滤隐藏 Sheet 的逻辑完全对称：AI 眼中不存在。
    """
    hidden_rows = set()
    for row_idx, rd in ws.row_dimensions.items():
        if rd.hidden:
            hidden_rows.add(row_idx)

    hidden_cols = set()
    for col_letter, cd in ws.column_dimensions.items():
        if cd.hidden:
            try:
                hidden_cols.add(column_index_from_string(col_letter))
            except Exception:
                pass

    return hidden_rows, hidden_cols


# ─────────────────────────────────────────────────────────────
# 行分析：为每一行生成 profile
# ─────────────────────────────────────────────────────────────

def build_merged_index(ws):
    """把 merged_cells 整理成列表，方便查询"""
    merged = []
    for mr in ws.merged_cells.ranges:
        merged.append({
            'min_row': mr.min_row, 'max_row': mr.max_row,
            'min_col': mr.min_col, 'max_col': mr.max_col
        })
    return merged


# 默认背景色（白色/None）的归一化形式，用于判断"有无自定义背景色"
_DEFAULT_BG = {'00000000', 'FFFFFFFF', 'FF000000', None, '00FFFFFF'}

def _cell_bg_color(cell) -> str | None:
    """返回单元格背景色的 ARGB 字符串，默认/白色返回 None。"""
    try:
        fill = cell.fill
        if fill and fill.fill_type not in (None, 'none'):
            fg = fill.fgColor
            if fg:
                argb = fg.rgb if fg.type == 'rgb' else None
                if argb and argb not in _DEFAULT_BG:
                    return argb
    except Exception:
        pass
    return None


def _cell_font_size(cell) -> float | None:
    """返回单元格字号，无自定义则返回 None。"""
    try:
        if cell.font and cell.font.size:
            return float(cell.font.size)
    except Exception:
        pass
    return None


def row_profile(ws, row_idx: int, max_col: int, merged: list,
                hidden_cols: set = None) -> dict:
    """分析单行，返回其类型 profile（含视觉信号：背景色、字号、粗体）
    hidden_cols: 隐藏列编号集合（1-based），传入后自动跳过，AI 眼中不存在。
    """
    if hidden_cols is None:
        hidden_cols = set()
    cells = [ws.cell(row=row_idx, column=c)
             for c in range(1, max_col + 1) if c not in hidden_cols]
    # 记录每个 cell 对应的实际列号（过滤后）
    col_indices = [c for c in range(1, max_col + 1) if c not in hidden_cols]
    values = [c.value for c in cells]
    non_empty = [(col_indices[i], v) for i, v in enumerate(values) if v is not None]

    if not non_empty:
        return {'row': row_idx, 'type': 'empty'}

    # ── 宽合并标题检测 ──────────────────────────────────────────
    wide_merge_text = None
    for mr in merged:
        if (mr['min_row'] == row_idx and
                mr['max_col'] - mr['min_col'] >= 1):   # ≥2列跨度即视为标题信号
            cv = ws.cell(row=row_idx, column=mr['min_col']).value
            if cv and isinstance(cv, str) and cv.strip():
                wide_merge_text = cv.strip()
                break

    # ── 类型统计 ───────────────────────────────────────────────
    text_cnt = sum(1 for _, v in non_empty if isinstance(v, str))
    total    = len(non_empty)
    text_ratio = text_cnt / total if total else 0

    dominant = (
        'text'    if text_ratio > 0.55  else
        'numeric' if (1 - text_ratio) > 0.55 else
        'mixed'
    )

    # ── 视觉信号：粗体、字号、背景色 ──────────────────────────
    is_bold       = False
    max_font_size = None
    bg_colors     = set()   # 该行出现的非默认背景色

    for col_idx, _ in non_empty:
        cell = ws.cell(row=row_idx, column=col_idx)
        # 粗体（取任意一个有粗体的格子即认定）
        if not is_bold and cell.font and cell.font.bold:
            is_bold = True
        # 字号（取行内最大字号）
        sz = _cell_font_size(cell)
        if sz and (max_font_size is None or sz > max_font_size):
            max_font_size = sz
        # 背景色
        bg = _cell_bg_color(cell)
        if bg:
            bg_colors.add(bg)

    col_min = non_empty[0][0]
    col_max = non_empty[-1][0]

    # ── 注释/备注行检测（通用，不依赖文本前缀）──────────────────
    # 判断标准：跨列合并 + 几乎只有一格内容 + 全是文字
    #           + （含换行符 OR 含句子标点）→ 说明是一段说明文字，不是标题
    # 子表标题通常是短字符串无标点，注释/说明通常包含换行或完整句子
    _SENTENCE_PUNCTS = set('，。；：！？、\n')
    is_comment_row = False
    if wide_merge_text is not None and total <= 2 and text_ratio == 1.0:
        has_sentence_signal = any(ch in _SENTENCE_PUNCTS for ch in wide_merge_text)
        is_comment_row = has_sentence_signal

    return {
        'row':             row_idx,
        'type':            'comment' if is_comment_row else 'data',
        'wide_merge_text': None if is_comment_row else wide_merge_text,  # 注释行不触发标题逻辑
        'dominant':        dominant,
        'is_bold':         is_bold,
        'max_font_size':   max_font_size,   # 新增：行内最大字号
        'has_bg_color':    len(bg_colors) > 0,  # 新增：是否有非白色背景
        'bg_colors':       list(bg_colors),     # 新增：出现的背景色列表
        'text_ratio':      text_ratio,
        'non_empty_count': total,
        'col_min':         col_min,
        'col_max':         col_max,
    }


# ─────────────────────────────────────────────────────────────
# TableBlock 数据结构
# ─────────────────────────────────────────────────────────────

class TableBlock:
    _counter = 0

    @classmethod
    def reset(cls):
        cls._counter = 0

    def __init__(self):
        TableBlock._counter += 1
        self.table_id   = f"T{TableBlock._counter:02d}"
        self.title      = None
        self.title_row  = None
        self.header_row = None
        self.columns    = {}   # col_letter → 列名
        self.data_start = None
        self.data_end   = None
        self.col_min    = None
        self.col_max    = None
        self.confidence = 'medium'

    def update_col_range(self, col_min: int, col_max: int):
        if self.col_min is None or col_min < self.col_min:
            self.col_min = col_min
        if self.col_max is None or col_max > self.col_max:
            self.col_max = col_max

    def is_valid(self) -> bool:
        return self.data_start is not None

    def to_dict(self) -> dict:
        return {
            "table_id":  self.table_id,
            "title":     self.title,
            "title_row": self.title_row,
            "header_row": self.header_row,
            "data_rows": {
                "start": self.data_start,
                "end":   self.data_end,
            },
            "col_range": {
                "start": get_column_letter(self.col_min) if self.col_min else None,
                "end":   get_column_letter(self.col_max) if self.col_max else None,
            },
            "columns":    self.columns,
            "confidence": self.confidence,
            "sibling":    getattr(self, 'sibling', None),      # 水平并排引用
            "split_confidence": getattr(self, 'split_confidence', None),  # 列分割置信度
        }


# ─────────────────────────────────────────────────────────────
# 列头提取
# ─────────────────────────────────────────────────────────────

def extract_header_columns(ws, header_row: int, max_col: int, merged: list) -> dict:
    """从 header_row 提取 列字母 → 列名 映射（处理合并列头）"""
    columns = {}
    col_idx = 1
    while col_idx <= max_col:
        cell = ws.cell(row=header_row, column=col_idx)
        val  = cell.value
        if val is not None and str(val).strip():
            col_name = str(val).strip()
            # 检测合并跨度
            span = 1
            for mr in merged:
                if (mr['min_row'] <= header_row <= mr['max_row'] and
                        mr['min_col'] == col_idx):
                    span = mr['max_col'] - mr['min_col'] + 1
                    break
            for offset in range(span):
                col_letter = get_column_letter(col_idx + offset)
                columns[col_letter] = col_name
            col_idx += span
        else:
            col_idx += 1
    return columns


# ─────────────────────────────────────────────────────────────
# 水平列分割逻辑
# ─────────────────────────────────────────────────────────────

def detect_column_splits(ws, row_start: int, row_end: int,
                         col_start: int, col_end: int,
                         merged: list) -> dict:
    """
    在给定的行块（row_start~row_end）和列范围（col_start~col_end）内，
    检测是否存在水平并排的独立子表。

    判断信号（按强度排序）：
      强：整列为空（空封率 > 90%），且两侧都有数据
      强：合并单元格的起始列在该范围内，且不是行最左列（说明右侧另起新表）
      中：列密度（非空率）出现明显断层
      弱：左右两侧背景色体系明显不同

    返回：
    {
        "splits": [
            {"col_start": 1, "col_end": 5, "confidence": "high"},
            {"col_start": 7, "col_end": 19, "confidence": "high"},
        ],
        "overall_confidence": "high" | "medium" | "low",
        "pending_review": False,   # True = 工具不确定，需要用户确认
        "split_cols": [6],         # 发现的空列/分割列号列表
    }
    """
    if row_end < row_start or col_end < col_start:
        return {"splits": [{"col_start": col_start, "col_end": col_end,
                             "confidence": "high"}],
                "overall_confidence": "high", "pending_review": False, "split_cols": []}

    num_rows = row_end - row_start + 1
    num_cols = col_end - col_start + 1

    # 不值得分割（列数太少）
    if num_cols < 4:
        return {"splits": [{"col_start": col_start, "col_end": col_end,
                             "confidence": "high"}],
                "overall_confidence": "high", "pending_review": False, "split_cols": []}

    # ── 1. 计算每列的空封率 ──────────────────────────────────────
    col_empty_rate = {}   # col_idx → 空封率 (0~1)
    col_nonzero    = {}   # col_idx → 非空行数

    for c in range(col_start, col_end + 1):
        empty = 0
        for r in range(row_start, row_end + 1):
            v = ws.cell(row=r, column=c).value
            if v is None or (isinstance(v, str) and v.strip() == ''):
                empty += 1
        col_empty_rate[c] = empty / num_rows if num_rows else 1.0
        col_nonzero[c]    = num_rows - empty

    # ── 2. 合并单元格信号：找"在范围内、且不是范围最左"的合并起始列 ──
    merge_starts = set()
    for mr in merged:
        # 合并单元格横跨行范围，且起始列不是 col_start
        if (mr['min_row'] >= row_start and mr['max_row'] <= row_end and
                mr['min_col'] > col_start and mr['min_col'] <= col_end and
                mr['max_col'] - mr['min_col'] >= 1):
            merge_starts.add(mr['min_col'])

    # ── 3. 寻找空列分割点 ────────────────────────────────────────
    EMPTY_THRESHOLD = 0.85   # 空封率 > 85% 认为是空列
    empty_cols = [c for c in range(col_start, col_end + 1)
                  if col_empty_rate[c] >= EMPTY_THRESHOLD]

    # 连续空列合并成一段，找到每段的中点作为分割边界
    split_gaps = []   # [(gap_start, gap_end)]
    if empty_cols:
        gap_s = empty_cols[0]
        gap_e = empty_cols[0]
        for c in empty_cols[1:]:
            if c == gap_e + 1:
                gap_e = c
            else:
                split_gaps.append((gap_s, gap_e))
                gap_s = gap_e = c
        split_gaps.append((gap_s, gap_e))

    # ── 4. 合并信号推导分割候选 ──────────────────────────────────
    # 候选分割位置：空列段右端 or 合并单元格的左端（作为新表起始）
    # 形如：[(left_block_end, right_block_start, confidence)]
    candidates = []

    for (gs, ge) in split_gaps:
        # 两侧必须都有数据
        left_has_data  = any(col_nonzero.get(c, 0) > 0 for c in range(col_start, gs))
        right_has_data = any(col_nonzero.get(c, 0) > 0 for c in range(ge + 1, col_end + 1))
        if left_has_data and right_has_data:
            # 检查右侧起始是否有合并单元格信号
            right_start = ge + 1
            has_merge_signal = right_start in merge_starts
            conf = "high" if has_merge_signal else "medium"
            candidates.append((gs - 1, ge + 1, conf))

    # 仅有合并信号、没有空列时也加入候选
    for mc in merge_starts:
        already = any(abs(mc - c[1]) <= 1 for c in candidates)
        if not already:
            # 向左找上一个非空列
            left_end = mc - 1
            # 向右：mc 本身是新表起始
            left_has_data  = any(col_nonzero.get(c, 0) > 0 for c in range(col_start, mc))
            right_has_data = any(col_nonzero.get(c, 0) > 0 for c in range(mc, col_end + 1))
            if left_has_data and right_has_data:
                candidates.append((left_end, mc, "medium"))

    # ── 5. 没有足够信号 → 不分割 ────────────────────────────────
    if not candidates:
        return {
            "splits": [{"col_start": col_start, "col_end": col_end, "confidence": "high"}],
            "overall_confidence": "high",
            "pending_review": False,
            "split_cols": [],
        }

    # ── 6. 按分割点排序，构建 splits ─────────────────────────────
    candidates.sort(key=lambda x: x[0])

    blocks = []
    prev_start = col_start
    split_col_list = []
    overall_conf = "high"

    for (left_end, right_start, conf) in candidates:
        if left_end >= prev_start:
            blocks.append({"col_start": prev_start, "col_end": left_end,
                           "confidence": conf})
            split_col_list.append((left_end, right_start))
            prev_start = right_start
        if conf == "medium":
            overall_conf = "medium"
    blocks.append({"col_start": prev_start, "col_end": col_end,
                   "confidence": overall_conf})

    # ── 7. 置信度判断：是否需要人工确认 ─────────────────────────
    pending = overall_conf in ("medium", "low") and len(blocks) > 1

    return {
        "splits":              blocks,
        "overall_confidence":  overall_conf,
        "pending_review":      pending,
        "split_cols":          [f"{le}→{rs}" for (le, rs) in split_col_list],
    }


def split_table_horizontally(table: TableBlock, ws,
                              merged: list) -> list:
    """
    对单个 TableBlock 做水平列分割，返回分割后的 TableBlock 列表。
    如果不需要分割（或置信度不足），返回原始列表（含一个元素）。
    分割后的兄弟表用 sibling 字段互相引用。
    """
    row_start = table.data_start or (table.header_row or table.title_row or 1)
    row_end   = table.data_end   or row_start
    col_start = table.col_min    or 1
    col_end   = table.col_max    or (ws.max_column or 1)

    # 扩展检测行范围：包含 title_row / header_row，捕捉标题合并单元格信号
    scan_start = min(
        row_start,
        table.title_row  if table.title_row  else row_start,
        table.header_row if table.header_row else row_start,
    )
    result = detect_column_splits(ws, scan_start, row_end,
                                  col_start, col_end, merged)

    if len(result["splits"]) <= 1:
        # 不需要分割
        table.split_confidence = result["overall_confidence"]
        return [table]

    # 需要分割，为每块生成新的 TableBlock
    # 标题归属：只有合并标题所在列范围（title_col_start）包含在该 block 内的才继承 title
    title_col_start = None
    if table.title_row:
        for mr in merged:
            if mr['min_row'] == table.title_row:
                title_col_start = mr['min_col']
                break

    new_tables = []
    for seg in result["splits"]:
        t = TableBlock()
        # 只有当合并标题的起始列在当前 block 的列范围内时，才继承 title
        if (title_col_start is not None and
                seg["col_start"] <= title_col_start <= seg["col_end"]):
            t.title     = table.title
            t.title_row = table.title_row
        else:
            t.title     = None
            t.title_row = None
        t.header_row = table.header_row
        t.data_start = table.data_start
        t.data_end   = table.data_end
        t.col_min    = seg["col_start"]
        t.col_max    = seg["col_end"]
        t.confidence = table.confidence
        t.split_confidence = seg["confidence"]
        # 重新提取对应列范围内的列头
        if table.header_row:
            t.columns = {
                k: v for k, v in table.columns.items()
                if seg["col_start"] <= col_letter_to_idx(k) <= seg["col_end"]
            }
        else:
            t.columns = {}
        new_tables.append(t)

    # 设置 sibling 引用（互相指向兄弟表的 table_id）
    ids = [t.table_id for t in new_tables]
    for i, t in enumerate(new_tables):
        t.sibling = [ids[j] for j in range(len(ids)) if j != i]

    # pending_review 时给第一个子表打标
    if result["pending_review"]:
        new_tables[0].split_confidence = "pending_review"

    return new_tables


# ─────────────────────────────────────────────────────────────
# 子表检测状态机
# ─────────────────────────────────────────────────────────────

def detect_tables(ws, sheet_name: str) -> list:
    """
    主检测函数：遍历所有行，用状态机识别子表边界。

    States:
      BETWEEN   — 表间空白区
      IN_TITLE  — 刚看到宽合并标题，等待 header/data
      IN_HEADER — 看到列头行，等待数据
      IN_DATA   — 在数据区

    隐藏行/列与隐藏 Sheet 逻辑对称：自动跳过，AI 眼中不存在。
    """
    TableBlock.reset()
    max_row = ws.max_row or 0
    max_col = ws.max_column or 0
    if max_row == 0 or max_col == 0:
        return []

    # 构建隐藏集合（与 sheet_state 过滤同级别）
    hidden_rows, hidden_cols = _build_hidden_sets(ws)
    if hidden_rows or hidden_cols:
        print(f"  [过滤] Sheet '{sheet_name}' — 隐藏行: {sorted(hidden_rows)}, "
              f"隐藏列idx: {sorted(hidden_cols)}")

    merged = build_merged_index(ws)
    # 隐藏行直接当 empty 处理（从 profile 列表中跳过，效果等同于行不存在）
    profiles = []
    for r in range(1, max_row + 1):
        if r in hidden_rows:
            profiles.append({'row': r, 'type': 'empty'})  # 隐藏行视为空行
        else:
            profiles.append(row_profile(ws, r, max_col, merged, hidden_cols))

    tables  = []
    current = None
    state   = 'BETWEEN'

    def close_current():
        nonlocal current
        if current and current.is_valid():
            current.confidence = 'high' if current.header_row else 'medium'
            tables.append(current)
        current = None

    for p in profiles:
        row = p['row']

        # ── 空行 / 注释行（统一处理，关闭当前数据块）──────────
        if p['type'] in ('empty', 'comment'):
            if state == 'IN_DATA':
                current.data_end = row - 1
                close_current()
                state = 'BETWEEN'
            elif state in ('IN_TITLE', 'IN_HEADER'):
                # 标题/列头行后紧跟空行 → 暂不关闭，等后续行
                pass
            continue

        # ── 非空行 ────────────────────────────────────────────
        is_title_row   = p.get('wide_merge_text') is not None
        is_text_heavy  = p.get('dominant') == 'text'
        is_bold        = p.get('is_bold', False)
        col_min        = p.get('col_min', 1)
        col_max        = p.get('col_max', max_col)

        # 宽合并标题行
        if is_title_row:
            if state == 'IN_DATA':
                current.data_end = row - 1
                close_current()
            elif state in ('IN_TITLE', 'IN_HEADER'):
                close_current()
            current = TableBlock()
            current.title     = p['wide_merge_text']
            current.title_row = row
            current.update_col_range(col_min, col_max)
            state = 'IN_TITLE'

        # 文字为主 → 列头行（在 BETWEEN 或 IN_TITLE 后）
        elif is_text_heavy and state in ('BETWEEN', 'IN_TITLE'):
            if current is None:
                current = TableBlock()
            current.header_row = row
            current.columns    = extract_header_columns(ws, row, max_col, merged)
            current.update_col_range(col_min, col_max)
            state = 'IN_HEADER'

        # 粗体文字行出现在数据区中途 → 视为新子表的列头
        elif is_text_heavy and is_bold and state == 'IN_DATA':
            current.data_end = row - 1
            close_current()
            current            = TableBlock()
            current.header_row = row
            current.columns    = extract_header_columns(ws, row, max_col, merged)
            current.update_col_range(col_min, col_max)
            state = 'IN_HEADER'

        # 数据行
        else:
            if state == 'BETWEEN':
                current = TableBlock()   # 无标题无列头，直接开始数据
                state   = 'IN_DATA'
            if current is None:
                current = TableBlock()
                state   = 'IN_DATA'
            if current.data_start is None:
                current.data_start = row
            current.data_end = row
            current.update_col_range(col_min, col_max)
            if state != 'IN_DATA':
                state = 'IN_DATA'

    # 收尾
    if state == 'IN_DATA' and current:
        close_current()

    # ── 水平列分割后处理 ──────────────────────────────────────
    # 对每个垂直子表尝试做水平分割，生成并排子表
    final_tables = []
    for t in tables:
        sub = split_table_horizontally(t, ws, merged)
        final_tables.extend(sub)

    # 重新分配 table_id（按 final_tables 顺序）
    TableBlock.reset()
    for t in final_tables:
        t.table_id = f"T{TableBlock._counter + 1:02d}"
        TableBlock._counter += 1

    # 更新 sibling 引用（需要在 table_id 重置后重做）
    # sibling 已经在 split_table_horizontally 里用老 id 填了，
    # 这里做一次 id 修正：找有 sibling 的表，把 old_id 映射到 new_id
    # 简化处理：同批兄弟表的 title + row_range 相同，重新扫描
    for i, t in enumerate(final_tables):
        if getattr(t, 'sibling', None):
            siblings = []
            for j, other in enumerate(final_tables):
                if j != i and (
                    other.data_start == t.data_start and
                    other.data_end   == t.data_end   and
                    other.col_min    != t.col_min
                ):
                    siblings.append(other.table_id)
            t.sibling = siblings if siblings else None

    return final_tables


# ─────────────────────────────────────────────────────────────
# 语义解析器（供外部 import）
# ─────────────────────────────────────────────────────────────

def resolve_cell_semantic(cell_ref: str, tables_dict: list) -> dict:
    """
    给定格子引用（'F45' 或 '$E$46'），在 tables_dict 中查找它属于哪个子表。
    返回 {"table_id", "table_title", "column_name", "relative_row", "abs_row"}
    """
    col, row = parse_cell_ref(cell_ref)
    if col is None:
        return None

    col_idx = col_letter_to_idx(col)

    for t in tables_dict:
        d  = t.get('data_rows', {})
        cr = t.get('col_range', {})
        ds, de = d.get('start'), d.get('end')
        cs, ce = cr.get('start'), cr.get('end')

        if ds and de and ds <= row <= de:
            if cs and ce:
                cs_idx = col_letter_to_idx(cs)
                ce_idx = col_letter_to_idx(ce)
                if cs_idx <= col_idx <= ce_idx:
                    col_name = t.get('columns', {}).get(col, f"列{col}")
                    return {
                        "table_id":    t['table_id'],
                        "table_title": t.get('title') or t['table_id'],
                        "column_name": col_name,
                        "relative_row": row - ds + 1,
                        "abs_row":     row,
                    }

        # 也检测列头行
        if t.get('header_row') == row:
            return {
                "table_id":    t['table_id'],
                "table_title": t.get('title') or t['table_id'],
                "column_name": "(列标题行)",
                "relative_row": 0,
                "abs_row":     row,
            }

    return {
        "table_id":    "?",
        "table_title": "未归属区域",
        "column_name": f"列{col}",
        "relative_row": row,
        "abs_row":     row,
    }


def build_semantic_refs(formula: str, tables_dict: list) -> dict:
    """
    对公式中每个引用格子做语义解析，返回
    { "F45": {"table_id": ..., "column_name": ..., ...}, ... }
    """
    refs = extract_refs_from_formula(formula or '')
    result = {}
    for ref in set(refs):
        sem = resolve_cell_semantic(ref, tables_dict)
        if sem:
            result[ref] = sem
    return result


# ─────────────────────────────────────────────────────────────
# 输出生成
# ─────────────────────────────────────────────────────────────

def write_schema(schema: dict, out_path: Path):
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(schema, f, ensure_ascii=False, indent=2)


def generate_summary_md(all_schemas: list, output_dir: Path):
    lines = [
        "# Excel 子表 Schema 摘要",
        f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
    ]
    for schema in all_schemas:
        if not schema:
            continue
        lines += [
            f"## Sheet: {schema['sheet']}",
            f"共 {schema['table_count']} 个子表",
            "",
        ]
        for t in schema['tables']:
            d  = t['data_rows']
            cr = t['col_range']
            lines += [
                f"### {t['table_id']}: {t['title'] or '（无标题）'}",
                f"- 行范围: R{d['start']} ~ R{d['end']}",
                f"- 列范围: {cr['start']} ~ {cr['end']}",
            ]
            if t.get('header_row'):
                lines.append(f"- 表头行: Row {t['header_row']}")
            lines.append(f"- 置信度: {t['confidence']}")
            if t['columns']:
                lines.append("- 列含义:")
                for col_letter, col_name in sorted(t['columns'].items(),
                                                    key=lambda x: col_letter_to_idx(x[0])):
                    lines.append(f"  - 列 {col_letter}: {col_name}")
            lines.append("")

    summary_path = output_dir / "table_schema_summary.md"
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    print(f"\n✅ 摘要 → {summary_path}")


# ─────────────────────────────────────────────────────────────
# 主流程
# ─────────────────────────────────────────────────────────────

def _screenshot_score(ws, tables_dict: list, image_count: int = 0) -> dict:
    """
    计算 Sheet 的截图必要性得分。
    得分 ≥ 3 → needs_screenshot = True

    评分规则：
      +2  列数 > 30（宽表，很可能有并排子表）
      +2  有嵌入图片/图表
      +1  检测到非白色背景色行（色彩语义编码）
      +1  有 medium/low 置信度的子表
      -1  所有子表都是 high 置信度且列数 < 25
    """
    score = 0
    reasons = []

    max_col = ws.max_column or 0
    if max_col > 30:
        score += 2
        reasons.append(f"列数={max_col}(>30) +2")

    if image_count > 0:
        score += 2
        reasons.append(f"嵌入图片{image_count}张 +2")

    # 检测是否有非白色背景色行
    has_bg = False
    sample_rows = min(ws.max_row or 0, 50)
    for r in range(1, sample_rows + 1):
        for c in range(1, min(max_col + 1, 20)):
            if _cell_bg_color(ws.cell(row=r, column=c)):
                has_bg = True
                break
        if has_bg:
            break
    if has_bg:
        score += 1
        reasons.append("有背景色 +1")

    # 子表置信度
    confidences = [t.get('confidence', 'medium') for t in tables_dict]
    if any(c in ('medium', 'low') for c in confidences):
        score += 1
        reasons.append("有medium/low子表 +1")
    if all(c == 'high' for c in confidences) and max_col < 25:
        score -= 1
        reasons.append("全high+窄表 -1")

    return {
        "score":            score,
        "needs_screenshot": score >= 3,
        "reasons":          reasons,
    }


def process_sheet(excel_path: Path, sheet_name: str,
                  output_dir: Path, sheet_idx: int,
                  image_count: int = 0) -> dict:
    wb = openpyxl.load_workbook(str(excel_path), data_only=True)
    if sheet_name not in wb.sheetnames:
        print(f"  ⚠ Sheet 不存在: {sheet_name}")
        return None

    ws = wb[sheet_name]
    tables_raw  = detect_tables(ws, sheet_name)
    tables_dict = [t.to_dict() for t in tables_raw]

    # 截图评分
    ss_result = _screenshot_score(ws, tables_dict, image_count)

    schema = {
        "sheet":            sheet_name,
        "generated_at":     datetime.now().strftime("%Y-%m-%d %H:%M"),
        "table_count":      len(tables_dict),
        "screenshot_score": ss_result["score"],
        "needs_screenshot": ss_result["needs_screenshot"],
        "screenshot_reasons": ss_result["reasons"],
        "tables":           tables_dict,
    }

    sheet_dir = output_dir / f"sheet_{sheet_idx:02d}_data"
    sheet_dir.mkdir(parents=True, exist_ok=True)
    out_path  = sheet_dir / "table_schema.json"
    write_schema(schema, out_path)

    print(f"  Sheet [{sheet_idx:02d}] {sheet_name}: "
          f"{len(tables_dict)} 个子表 → {out_path.name}")
    return schema


def main():
    parser = argparse.ArgumentParser(description='Excel Sub-Table Schema Extractor')
    parser.add_argument('excel_path')
    parser.add_argument('--tag', required=True)
    parser.add_argument('--sheets', nargs='+')
    parser.add_argument('--all-sheets', action='store_true')
    args = parser.parse_args()

    excel_path = Path(args.excel_path)
    output_dir = excel_path.parent / f"{args.tag}_export"
    output_dir.mkdir(exist_ok=True)

    wb = openpyxl.load_workbook(str(excel_path), data_only=True)

    if args.all_sheets:
        # 默认只处理可见 Sheet，跳过隐藏
        sheet_names = [ws.title for ws in wb.worksheets
                       if ws.sheet_state == 'visible']
        hidden = [ws.title for ws in wb.worksheets
                  if ws.sheet_state != 'visible']
        if hidden:
            print(f"  ⚠ 跳过 {len(hidden)} 个隐藏 Sheet: {hidden}")
    else:
        sheet_names = args.sheets or wb.sheetnames[:1]

    # 读取 sheet_mapping.json 获取正确的 sheet 索引
    mapping_path = output_dir / "sheet_mapping.json"
    sheet_idx_map = {}
    if mapping_path.exists():
        with open(mapping_path, encoding='utf-8') as f:
            mapping = json.load(f)
        # mapping 可能是 dict {name: dirname} 或 list [{sheet_name, dir_name}]
        if isinstance(mapping, dict):
            items = mapping.items()
        elif isinstance(mapping, list):
            items = [(entry.get('sheet_name', ''), entry.get('dir_name', ''))
                     for entry in mapping if isinstance(entry, dict)]
        else:
            items = []
        for name, dirname in items:
            m = re.match(r'sheet_(\d+)_data', str(dirname))
            if m:
                sheet_idx_map[name] = int(m.group(1))

    print(f"处理 {len(sheet_names)} 个 Sheet ...\n")
    all_schemas = []
    for i, name in enumerate(sheet_names, 1):
        idx    = sheet_idx_map.get(name, i)
        schema = process_sheet(excel_path, name, output_dir, idx)
        all_schemas.append(schema)

    generate_summary_md(all_schemas, output_dir)
    print(f"\nDone. 输出目录: {output_dir}")


if __name__ == '__main__':
    main()
