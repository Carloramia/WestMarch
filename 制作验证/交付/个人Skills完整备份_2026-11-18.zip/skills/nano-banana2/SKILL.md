---
name: nano-banana2
description: Generate or edit raster images through the user's Nano Banana2 or Gemini image API workflow when that provider is explicitly requested or already selected for the task. Do not claim all image requests; use the ordinary available image tool for provider-unspecified requests.
metadata:
  version: "1.5.0"
allowed-tools:
  - Task
  - Bash
  - Read
  - Write
---

# Nano Banana2 Provider Workflow

Use this provider-specific entrypoint only when the user's requested or established workflow calls for Nano Banana2/Gemini. Do not change providers, endpoints or billing arrangements merely because this skill is installed.

Read [the provider guide](provider-guide.md) for the existing `scripts/api.py` invocation, supported sizes, input images and response handling. Script and configuration paths remain relative to this skill's root; the preserved guide's old global trigger wording does not expand this scope.

Do not read or print private `.env` contents or API keys. Let the existing script report missing authentication. Preserve source images and existing transparency as appropriate, distinguish edits from new generations, inspect the output and stop at authentication, safety or provider errors rather than silently switching services.
