# suno-v2

SUNO AI 音乐自动化创作 skill。

完整的音乐创作工作流：收集音乐需求 → 分析提示词库生成多个音乐方向 → 用户确认 → Playwright 自动化在 SUNO 网站批量创建音乐。

## 功能

- 对话式需求收集（支持文档导入或关键词描述）
- 提示词库智能匹配（项目编号、风格、乐器、氛围）
- 生成 3 个差异化音乐方向供用户选择
- Playwright + CDP 自动化批量创建音乐
- Share Link 批量收集
- Excel 需求文件直接转换为 SUNO 配置

## 安装

```
npx skills add https://skills.netease.com/api/git/@suno-v2.git
```

安装后需在 skill 目录下安装 Node.js 依赖：

```bash
cd ~/.sonus-assistant/skills/suno-v2
npm install
```

## 依赖

- Node.js 18+
- Playwright（通过 npm install 自动安装）
- Chrome 浏览器（CDP 调试模式连接）

## 仓库结构

```
.
├── manifest.json          # skill 元信息
├── package.json           # Node.js 依赖
├── prompt/
│   └── system.md          # skill 主提示词
├── scripts/
│   ├── suno_browser.js    # Playwright 自动化主脚本
│   ├── read_requirement_excel.js  # Excel 需求解析
│   ├── discover_workspace.js      # Workspace 发现
│   ├── discover_ws_flow.js        # Workspace 流程发现
│   ├── keep_open.js               # 保持页面打开
│   └── (CI 脚本: render_hub_skill.py, upload.py, etc.)
├── references/
│   ├── excel_library_guide.md     # 提示词库字段说明
│   ├── suno_ui_selectors.md       # SUNO UI 选择器参考
│   ├── 互娱AI音乐关键词整合 (2).xlsx  # 提示词库
│   ├── 复杂音乐需求模板.xlsx
│   └── 简单音乐需求模板.xlsx
└── .gitlab-ci.yml         # 共享 CI 引用
```
