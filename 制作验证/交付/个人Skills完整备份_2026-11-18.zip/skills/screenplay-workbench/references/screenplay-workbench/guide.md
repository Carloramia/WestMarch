---
name: screenplay-workbench
description: Develop and diagnose screenplays in Chinese or English, including character bibles, scene outlines, beat sheets, Fountain formatting, and story-continuity checks. Use for scripts, screenplays, episode outlines, scene rewrites, and continuity reviews; do not use for shot-by-shot camera planning.
---

# Screenplay workbench

Turn a premise or draft into production-usable story material while preserving the user's genre, format, and voice.

## Workflow

1. Identify the intended format, audience, length, tone, and current development stage. Ask only for a choice that would materially change the result.
2. Separate supplied facts from creative proposals. Mark unresolved items as `待确认`; never silently invent canon.
3. For development work, keep a traceable chain: premise -> character want/need/stakes -> beats -> scenes -> scene purpose and change.
4. For diagnosis, cite the scene or beat that supports each finding. Check causality, setup/payoff, motivation, escalation, pacing, point of view, and contradictions before proposing repairs.
5. For Fountain delivery, preserve plain text and standard screenplay elements. Use scene headings such as `INT./EXT. LOCATION - TIME`; keep action visual and playable; put character cues and dialogue on separate lines.
6. Maintain continuity fields for time, location, costume/props, injuries, knowledge, relationships, promises/setup, and unresolved threads.

## Outputs

Choose only the artifacts the request needs:

- character bible;
- beat sheet or scene-by-scene outline;
- Fountain screenplay;
- diagnosis table with evidence, severity, and repair options;
- continuity bible based on [the editable template](assets/continuity-bible-template.md).

Distinguish `确定内容`, `创作建议`, and `待确认`. Do not treat a structural framework as a rule the story must obey.

