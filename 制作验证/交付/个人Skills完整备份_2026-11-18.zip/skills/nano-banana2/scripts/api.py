"""
@purpose Nano Banana2 生图 API 调用脚本
@key-logic 调用 Gemini 3.1 Flash Image 模型生图，SSE 解析，base64 图片提取，支持本地文件和 URL 输入
"""

import argparse
import base64
import json
import mimetypes
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path


_SKILL_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv() -> None:
    """从 skill 根目录的 .env 文件加载环境变量（不覆盖已有值）"""
    env_file = _SKILL_DIR / ".env"
    if not env_file.is_file():
        return
    for raw in env_file.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip().strip("'\"")
        if key and key not in os.environ:
            os.environ[key] = val


_load_dotenv()

API_URL = os.environ.get(
    "API_BASE_URL", "https://aigw.nie.netease.com/v1/chat/completions"
)
MODEL = "gemini-3.1-flash-image"
TIMEOUT_SECONDS = 180  # 生图容易超时，建议 3 分钟

VALID_RATIOS = {"1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"}
VALID_SIZES = {"512", "1K", "2K", "4K"}

# 本地文件支持的图片格式
_SUPPORTED_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


# ── 本地文件转 data URI ──────────────────────────────
def resolve_image_source(source: str) -> str:
    """URL 直接返回，本地文件转为 base64 data URI"""
    if source.startswith(("http://", "https://", "data:")):
        return source
    fp = Path(source)
    if not fp.is_file():
        raise FileNotFoundError(f"本地图片文件不存在: {source}")
    if fp.suffix.lower() not in _SUPPORTED_IMAGE_EXTS:
        raise ValueError(
            f"不支持的图片格式: {fp.suffix}，支持: {', '.join(sorted(_SUPPORTED_IMAGE_EXTS))}"
        )
    mime = mimetypes.guess_type(str(fp))[0] or "image/png"
    b64 = base64.b64encode(fp.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{b64}"


def build_request_body(
    prompt: str, images: list[str], ratio: str | None, size: str | None, search: bool
) -> dict:
    """根据 CLI 参数构建 API 请求体"""
    content = []
    if prompt:
        content.append({"type": "text", "text": prompt})
    for source in images:
        # 本地文件自动转 base64 data URI，URL 原样传递
        resolved = resolve_image_source(source)
        content.append({"type": "image_url", "image_url": {"url": resolved}})
    if not content:
        raise ValueError("prompt 和 images 不能同时为空")

    body: dict = {
        "model": MODEL,
        "stream": True,
        "messages": [{"role": "user", "content": content}],
        "vertexai": {"response_modalities": ["TEXT", "IMAGE"]},
    }

    image_config = {}
    if ratio:
        if ratio not in VALID_RATIOS:
            raise ValueError(
                f"无效 ratio: {ratio}，支持: {', '.join(sorted(VALID_RATIOS))}"
            )
        image_config["aspect_ratio"] = ratio
    if size:
        if size not in VALID_SIZES:
            raise ValueError(
                f"无效 size: {size}，支持: {', '.join(sorted(VALID_SIZES))}"
            )
        image_config["image_size"] = size
    if image_config:
        body["vertexai"]["image_config"] = image_config

    if search:
        body["vertexai_tool"] = {"google_search_retrieval": {"open": True}}
    return body


def parse_sse_response(raw: bytes) -> tuple[str, list[bytes]]:
    """解析 SSE 流式响应，提取文本和图片"""
    text_parts: list[str] = []
    images: list[bytes] = []

    for line in raw.decode("utf-8", errors="replace").split("\n"):
        line = line.strip()
        if not line.startswith("data: "):
            continue
        payload = line[6:]
        if payload == "[DONE]":
            break
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            continue

        for choice in data.get("choices", []):
            delta = choice.get("delta", {})
            # 文本
            ct = delta.get("content")
            if isinstance(ct, str) and ct:
                text_parts.append(ct)
            elif isinstance(ct, list):
                for item in ct:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                    elif isinstance(item, str):
                        text_parts.append(item)
            # 图片（API 返回的核心字段）
            for uri in delta.get("image_urls") or []:
                if not isinstance(uri, str):
                    continue
                decoded = _decode_data_uri(uri)
                if decoded:
                    images.append(decoded)

    return "".join(text_parts).strip(), images


def _decode_data_uri(uri: str) -> bytes | None:
    """解码 data URI 或纯 base64 为原始字节"""
    if uri.startswith("data:"):
        idx = uri.find(",")
        if idx > 0:
            try:
                return base64.b64decode(uri[idx + 1 :])
            except Exception:
                return None
    # 兜底：纯 base64
    if len(uri) > 100:
        try:
            raw = base64.b64decode(uri)
            if raw[:4] == b"\x89PNG" or raw[:2] == b"\xff\xd8":
                return raw
        except Exception:
            pass
    return None


def save_images(images: list[bytes], output_dir: str, prefix: str) -> list[str]:
    """保存图片到指定目录，返回路径列表"""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths = []
    for i, data in enumerate(images):
        ext = "jpg" if data[:2] == b"\xff\xd8" else "png"
        suffix = f"_{i + 1}" if len(images) > 1 else ""
        fp = out / f"{prefix}{suffix}.{ext}"
        fp.write_bytes(data)
        paths.append(str(fp))
    return paths


def call_api(
    prompt: str,
    images: list[str],
    ratio: str | None,
    size: str | None,
    search: bool,
    output_dir: str,
    prefix: str,
) -> dict:
    """执行 API 调用，返回结构化结果"""
    token = os.environ.get("GEMINI_API_KEY")
    if not token:
        return {
            "success": False,
            "error": f"GEMINI_API_KEY 未配置，请在 {_SKILL_DIR / '.env'} 中设置 GEMINI_API_KEY=你的key",
            "error_type": "auth_missing",
        }

    try:
        body = build_request_body(prompt, images, ratio, size, search)
    except ValueError as e:
        return {"success": False, "error": str(e), "error_type": "invalid_params"}

    req = urllib.request.Request(
        API_URL,
        data=json.dumps(body).encode("utf-8"),
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as e:
        err_body = ""
        try:
            err_body = e.read().decode("utf-8", errors="replace")[:500]
        except Exception:
            pass
        etype = {
            429: "rate_limited",
            401: "auth_invalid",
            408: "timeout",
            504: "timeout",
        }.get(e.code, "http_error")
        return {
            "success": False,
            "error": f"HTTP {e.code}: {err_body}",
            "error_type": etype,
            "status_code": e.code,
        }
    except urllib.error.URLError as e:
        return {
            "success": False,
            "error": f"网络错误: {e.reason}",
            "error_type": "network_error",
        }
    except TimeoutError:
        return {
            "success": False,
            "error": f"请求超时（{TIMEOUT_SECONDS}s）",
            "error_type": "timeout",
        }

    text, img_list = parse_sse_response(raw)
    result: dict = {"success": True, "text": text, "image_count": len(img_list)}
    if img_list:
        result["saved_images"] = save_images(img_list, output_dir, prefix)
    else:
        result["warning"] = "API 未返回图片，可能 prompt 未触发生图或模型繁忙"
    return result


def main():
    p = argparse.ArgumentParser(description="Nano Banana2 生图")
    p.add_argument(
        "command", choices=["generate", "edit"], help="generate=文生图, edit=图片编辑"
    )
    p.add_argument("--prompt", required=True, help="图片描述或编辑指令")
    p.add_argument(
        "--image",
        "-i",
        action="append",
        default=[],
        help="图片 URL 或本地路径（可多次指定）",
    )
    p.add_argument("--ratio", "-r", help=f"宽高比: {', '.join(sorted(VALID_RATIOS))}")
    p.add_argument("--size", "-s", help=f"分辨率: {', '.join(sorted(VALID_SIZES))}")
    p.add_argument("--search", action="store_true", help="开启谷歌搜索辅助")
    p.add_argument(
        "--output-dir", "-o", default=".", help="图片保存目录（默认当前目录）"
    )
    p.add_argument("--prefix", "-p", default="", help="输出文件名前缀（默认按时间戳）")
    args = p.parse_args()

    prefix = args.prefix or f"image_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    result = call_api(
        args.prompt,
        args.image,
        args.ratio,
        args.size,
        args.search,
        args.output_dir,
        prefix,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result["success"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
