---
name: "copywriting-polish"
description: "Imported GameSpec skill: copywriting-polish"
---

# copywriting-polish

Use this skill when the user request matches this GameSpec capability.

## Source spec

- Read [references/spec.json](references/spec.json) and follow its fields, constraints, and output shape.
- If the source JSON is malformed, preserve intent by following file name and clearly state assumptions.
- Prefer structured outputs aligned with the schema in the source spec.
