---
name: nano-banana2
version: 1.5.0
description: >
  AI 图片生成和编辑工具。调用 Gemini 3.1 Flash Image (Nano Banana2) 模型，支持任意兼容代理。
  当用户想要生成图片、创建图像、画图、制作壁纸、海报背景、电商主图、头像等任何图片素材时，
  必须使用此 skill。当用户想要编辑已有图片（换背景、改风格、调色、风格迁移、多图合成拼图）时，
  也必须使用此 skill。支持文生图和图片编辑两种模式，支持本地文件和 URL 输入，
  支持宽高比和分辨率控制（512/1K/2K/4K）。
  即使用户没有直接说"生图"，只要意图是产出一张新图片或修改已有图片的视觉效果，就应触发此 skill。
  例如：用户说"画一只猫"、"做张海报"、"把照片改成动漫风"、"出张 3D 渲染图"、"来张壁纸"
  都属于此 skill 的范围。
  不适用于: 图片内容分析/识别/OCR（视觉理解任务）、视频生成、使用其他生图工具如 Stable Diffusion/DALL-E/Midjourney。
allowed-tools:
  - Task
  - Bash
  - Read
  - Write
user-invocable: true
---

# Nano Banana2 生图

> 调用 Gemini 3.1 Flash Image 模型，实现文生图和图片编辑。支持任意兼容的 API 代理，用户只需配置 `API_BASE_URL` 和 `GEMINI_API_KEY`。

本 SKILL.md 所在目录即为 skill 根目录，脚本位于 `scripts/api.py`（相对于本文件）。

## 执行流程

收到用户生图/图片编辑请求后，严格按以下步骤执行：

### 步骤 1：前置条件

**不要读取用户的 `.env` 文件**。直接跳到步骤 2 开始执行，如果 API key 未配置，脚本会返回 `error_type: auth_missing` 错误，届时再引导用户配置即可。

脚本自动从 skill 根目录下的 `.env` 文件加载 `GEMINI_API_KEY`（也兼容系统环境变量）。用户可通过 `API_BASE_URL` 自定义 API 端点。配置模板见 `.env.example`。

**Python 版本要求**：脚本使用了 `list[str]`、`str | None` 等语法，需要 **Python 3.10+**。

### 步骤 2：识别意图

根据用户输入判断子命令：

| 用户意图 | 子命令 | 判断依据 |
|---------|--------|---------|
| 纯文字描述，生成全新图片 | `generate` | 用户未提供现有图片 |
| 提供现有图片 + 修改指令 | `edit` | 用户提供了图片 URL 或本地文件路径 |

### 步骤 3：优化 Prompt

帮用户优化 prompt 可以显著提升生图质量。Gemini 的训练数据中英文图文配对样本远多于中文，英文描述能更精确地触发模型的视觉理解，所以主动将中文 prompt 翻译为英文。

优化方向：

1. **语言**：翻译为英文
2. **风格**：加入风格描述（"3D rendered", "watercolor", "photorealistic", "pixel art"）
3. **构图**：描述画面布局和视角（"bird's eye view", "close-up shot"）
4. **光照**：指定光照条件（"golden hour lighting", "studio lighting"）
5. **负面提示**：如有需要说明不要什么（"no text, no watermark"）

### 步骤 4：构造并执行命令

脚本路径为 `scripts/api.py`（相对于本 SKILL.md 所在目录）。

**基本格式：**

```bash
python "<skill-dir>/scripts/api.py" <command> --prompt "English prompt" [选项]
```

其中 `<skill-dir>` 替换为本 SKILL.md 所在目录的绝对路径。

**参数说明：**

| 参数 | 必填 | 说明 |
|------|------|------|
| `command` | 是 | `generate`（文生图）或 `edit`（图片编辑） |
| `--prompt TEXT` | 是 | 英文图片描述或编辑指令 |
| `-i, --image SOURCE` | edit 时 | 图片 URL 或本地文件路径，可多次指定 |
| `-r, --ratio RATIO` | 否 | 宽高比（用户未指定时不传） |
| `-s, --size SIZE` | 否 | 分辨率（用户未指定时不传） |
| `-o, --output-dir DIR` | 否 | 图片保存目录（默认当前目录） |
| `-p, --prefix NAME` | 否 | 文件名前缀（默认按时间戳） |
| `--search` | 否 | 开启谷歌搜索辅助（默认关闭） |

**宽高比映射：**

支持 `1:1` | `2:3` | `3:2` | `3:4` | `4:3` | `4:5` | `5:4` | `9:16` | `16:9` | `21:9`

- 用户说"竖屏"→ `9:16`，"横屏"→ `16:9`，"方形"→ `1:1`
- 用户未指定时不传此参数

**分辨率：** `512` | `1K` | `2K` | `4K`（越高越慢，4K 可能需要 2-3 分钟）

**图片输入：** `-i` 参数支持两种来源：
- URL：`https://example.com/photo.png`
- 本地文件路径：`D:\photos\my-pic.png` 或 `./photo.png`（脚本自动转为 base64 data URI）

**Prompt 转义提示：** 优先使用英文 prompt 以避免特殊字符问题。如果 prompt 含双引号，用 `\"` 转义。

### 步骤 5：处理结果

脚本输出 JSON 格式结果。根据 `success` 字段判断：

**成功时** — 向用户展示：

```
生成完成!
保存路径: <saved_images 中的路径>
分辨率: <用户设置的分辨率或默认>
模型描述: <text 字段内容，如果有>
```

如果 `image_count` 为 0（成功但无图片），说明 prompt 不够明确或触发了内容安全策略。优化 prompt 使其更明确地要求生成图片，最多重试 1 次。

**失败时** — 根据 `error_type` 分类处理：

#### 可重试的错误

| error_type | 含义 | 重试策略 |
|------------|------|---------|
| `rate_limited` | 资源池耗尽（Gemini 共享全球公共资源池，常见） | 等 10s → 30s → 60s，共 3 次 |
| `timeout` | 生图超时（默认 3 分钟） | 建议降低分辨率或简化 prompt 后重试 1 次 |
| `http_error` | 其他 HTTP 错误（5xx 等） | 等 10s 后重试 1 次 |

#### 不可重试的错误（直接告知用户修复）

| error_type | 含义 | 用户操作 |
|------------|------|---------|
| `auth_missing` | GEMINI_API_KEY 未配置 | 引导用户：复制 `.env.example` 为 `.env` 并填入 key |
| `auth_invalid` | Key 无效或过期 | 检查/更换 key |
| `invalid_params` | 参数错误（如无效的 ratio） | 修正参数 |
| `network_error` | 网络不可达 | 检查网络连接 |

### 步骤 6：多轮交互

如果用户对结果不满意：

- **"换个风格"** — 保留原始意图，调整 prompt 中的风格描述，重新生成（脚本用时间戳命名，不会覆盖之前的结果）
- **"再来一张"** — 相同参数重新调用，模型每次生成的结果不同
- **"调整比例/分辨率"** — 修改对应参数重新调用

## 调用示例

### 文生图

```bash
python "<skill-dir>/scripts/api.py" generate --prompt "A cyberpunk city at night with neon lights and flying cars, photorealistic, cinematic lighting" -r 16:9 -s 2K -o ./output
```

### 图片编辑（URL 输入）

```bash
python "<skill-dir>/scripts/api.py" edit --prompt "Change the background to a tropical beach at sunset" -i https://example.com/photo.png -r 1:1 -o ./output
```

### 图片编辑（本地文件）

```bash
python "<skill-dir>/scripts/api.py" edit --prompt "Convert to watercolor painting style" -i "D:\photos\my-pic.png" -o ./output
```

### 多图合成

```bash
python "<skill-dir>/scripts/api.py" edit --prompt "Combine these two images into a collage" -i https://img1.png -i "./local_photo.jpg" -o ./output
```
