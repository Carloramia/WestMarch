# Voice Design Prompting Guide

Translate user requests into the two required inputs:
- **Design prompt**: voice characteristics description
- **Preview text**: the line to speak (min 100 characters)

## Input Mapping Checklist

- User gives **both** voice description + line to speak -> proceed directly
- User gives **only voice description** -> ask: "What line should this voice speak?"
- User gives **only a line** -> ask: "What should the voice sound like? (gender, age, tone, pace, emotion)"
- Preview text under 100 chars -> ask user to expand it

## Prompt Dimensions

Build the design prompt by combining these dimensions:

| Dimension | Options |
|-----------|---------|
| Gender | male, female, androgynous |
| Age | child, young adult, middle-aged, elderly |
| Texture | smooth, raspy, breathy, nasal, deep, bright, husky, crisp |
| Emotion | warm, confident, playful, serious, mysterious, cheerful, melancholic |
| Pace | slow, moderate, fast |
| Style | news anchor, storyteller, narrator, casual, formal, cinematic |

## Example Mappings

### Chinese examples

1. User: "做一个温柔、轻声细语的女声，说一段欢迎词"
   - Prompt: "温柔、轻声细语的女声，语速偏慢，情绪温暖。"
   - Text: (ask user for specific welcome text, ensure 100+ chars)

2. User: "来个干练、清楚、略带新闻播报腔的男声，台词是版本更新公告"
   - Prompt: "干练清楚的男声，略带新闻播报腔，语速中等，咬字清晰。"
   - Text: (use the user's announcement text)

3. User: "想要成熟稳重、略沙哑的声音"
   - Prompt: "成熟稳重的男声，略带沙哑质感，语速中等，情绪沉稳。"
   - Text: (missing -- ask user)

4. User: "活泼可爱的少女音，适合游戏NPC"
   - Prompt: "活泼可爱的年轻女声，语速偏快，情绪开朗，带一点俏皮。"
   - Text: (missing -- ask user)

### English examples

5. User: "I need a deep, authoritative male narrator for a documentary"
   - Prompt: "Deep, authoritative male voice, mature, slow deliberate pace, cinematic narrator style, commanding presence."
   - Text: (ask user for narration text)

6. User: "Friendly female customer service voice"
   - Prompt: "Friendly young female voice, warm and approachable, moderate pace, professional but casual, cheerful."
   - Text: (ask user for the service script)

7. User: "Mysterious old wizard for a fantasy game"
   - Prompt: "Elderly male voice, slightly raspy and breathy, slow pace, mysterious and wise, storyteller quality."
   - Text: (ask user for dialog line)

8. User: "Energetic sports commentator"
   - Prompt: "Energetic male voice, bright and crisp, fast pace, excited and enthusiastic, broadcast style."
   - Text: (ask user for commentary text)

## Tips for Better Results

- **Be specific**: "warm female voice, 30s, smooth texture" beats "nice female voice"
- **Include pace**: pace significantly affects the output character
- **Mention context**: "for game NPC" or "for podcast intro" helps frame the style
- **Guidance tuning**: default 4.0; increase (6-8) for strict adherence, decrease (2-3) for more creative variation
- **Use reference audio**: when you have a target voice, `--reference` gives much better results than text description alone

## Defaults

| Parameter | Default | Notes |
|-----------|---------|-------|
| Model | eleven_ttv_v3 | Latest voice design model |
| Guidance | 4.0 | Higher = stricter adherence |
| Output format | pcm_48000 | 48kHz 16-bit mono WAV |
| Count | 3 | Generate 3 candidates |
