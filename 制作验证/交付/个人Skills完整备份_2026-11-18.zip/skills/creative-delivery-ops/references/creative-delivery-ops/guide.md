---
name: creative-delivery-ops
description: Plan and track creative work across script, copy, storyboard, review, and delivery, including requirement decomposition, owners, dependencies, status, approval gates, file handoffs, and definition of done. Use for creative production coordination and delivery checklists; do not contact people, change external systems, or mark approval complete without evidence.
---

# Creative delivery operations

Convert a request into an auditable production plan without replacing creative judgment.

## Workflow

1. Record the request, intended outcome, deliverables, constraints, decision owner, reviewers, due date, and source material.
2. Decompose work by deliverable and review gate. Each task needs an owner or `待分配`, an observable output, dependencies, status, and definition of done.
3. Use statuses: `未开始`, `进行中`, `待素材`, `待确认`, `待审核`, `修改中`, `已批准`, `已交付`, `阻塞`.
4. Keep approval distinct from completion. A file can be produced but still await editorial, brand, legal, or client approval.
5. Track version, filename, location, format, source rights, and handoff recipient for every deliverable.
6. Surface blockers and next decisions at the top. Never invent an owner, approval, deadline, or external-system state.

Use [the delivery board template](assets/delivery-board-template.md). For recurring status updates, show changes since the last version, current risks, and the next action—not a full rewrite of the plan.

