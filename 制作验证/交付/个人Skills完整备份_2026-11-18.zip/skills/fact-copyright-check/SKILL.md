---
name: fact-copyright-check
description: Review scripts, copy, briefs, shot plans, and creative assets for factual support, quotation accuracy, attribution, provenance, copyright, trademark, likeness, and licensing risk. Use before publication or delivery when claims or third-party material are present; provide risk triage, not legal advice or clearance.
---

# Fact and copyright check

Produce an evidence register and a practical risk triage. Do not imply legal clearance.

## Fact checking

1. Extract atomic checkable claims and label them `verified`, `partly supported`, `unverified`, `opinion`, or `fictional/canonical`.
2. Prefer primary sources, official records, original datasets, and the rightsholder's license terms. Record retrieval date and a direct URL or supplied-file location.
3. Distinguish absence of evidence from evidence of absence. Preserve conflicting sources and explain the conflict.
4. For quotations, verify exact wording, speaker, context, date, and permitted length. Paraphrase when quotation is unnecessary.

## Rights triage

For text, images, music, video, logos, characters, people, fonts, datasets, and AI-generated material, record creator/rightsholder, source, license or permission, attribution requirements, commercial-use limits, modification limits, territory/term if known, and proof retained.

Risk levels:

- `低`: ownership or compatible license is documented and obligations are understood.
- `中`: intended use may be allowed but license, attribution, model release, or provenance is incomplete.
- `高`: no permission, incompatible terms, substantial copying, misleading endorsement, privacy/likeness concern, or disputed ownership.

Escalate legal interpretation, fair-use/fair-dealing reliance, defamation, privacy, regulated claims, and high-risk commercial use to qualified counsel or the responsible reviewer. Use [the evidence register](assets/evidence-register-template.md).

