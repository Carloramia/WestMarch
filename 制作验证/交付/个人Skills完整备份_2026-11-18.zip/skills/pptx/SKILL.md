---
name: pptx
description: Inspect, repair and validate existing PPTX packages at the OOXML level using local unpack, clean, pack and validation helpers. Use for broken decks, package-level slide edits or an explicitly selected local PPTX workflow; use the available presentation authoring workflow for ordinary new decks.
license: Proprietary. LICENSE.txt has complete terms
---

# Local PPTX Repair and Package Tools

This is the low-level companion, not a second automatic entrypoint for every presentation request.

1. Identify the damaged or package-level behavior and preserve the supplied deck before edits.
2. Read [editing guidance](editing.md) for template/package edits, and inspect only the relevant slide parts and relationships.
3. Use the existing helpers under `scripts/office/` for unpacking, validation and packing; do not assume Word validators are appropriate for slide semantics.
4. Render and inspect the changed slides with available presentation/PDF tools. XML validity alone does not establish visual correctness.
5. Keep speaker notes, links, media, relationships and editable content unless the requested repair requires a documented change.

The [preserved local guide](legacy-guide.md) and [local authoring guide](pptxgenjs.md) remain available for an explicitly selected fallback when a higher-level presentation workflow is unavailable. Its broad historical trigger text does not override this scoped entrypoint.

Preserve upstream licensing metadata. The prior installed manifest referred to LICENSE.txt; do not infer redistribution rights if that text is not present in the source installation.
