# SUNO UI 选择器文档

本文件记录 SUNO (suno.com) 网页端的 UI 选择器，供 `suno_browser.js` 使用。
当 SUNO 更新 UI 导致自动化失败时，请使用 `--discover` 模式重新发现选择器并更新本文件和脚本。

**最后更新**: 2026-03-11

---

## 选择器注册表

### 登录检测
| 元素 | 注册键 | 选择器（按优先级） |
|------|--------|-------------------|
| 登录按钮 | `signInButton` | `button:has-text("Sign In")`, `button:has-text("Sign in")`, `button:has-text("Login")`, `a:has-text("Sign In")` |

### Create 页面 - 模式切换
| 元素 | 注册键 | 选择器 |
|------|--------|--------|
| Custom 模式 | `customModeToggle` | `button:has-text("Custom")`, `[data-testid="custom-toggle"]`, `button[aria-label*="Custom"]` |
| Instrumental 开关 | `instrumentalToggle` | `button:has-text("Instrumental")`, `[data-testid="instrumental-toggle"]`, `label:has-text("Instrumental")` |

### Create 页面 - 表单
| 元素 | 注册键 | 选择器 |
|------|--------|--------|
| Styles 输入框 | `stylesInput` | `textarea[placeholder*="Style"]`, `[data-testid="styles-textarea"]`, `textarea[aria-label*="Style"]`, `textarea[name*="style"]`, `input[placeholder*="Style"]`, `[contenteditable="true"][aria-label*="Style"]` |
| Lyrics 输入框 | `lyricsInput` | `textarea[placeholder*="Lyrics"]`, `[data-testid="lyrics-textarea"]`, `textarea[aria-label*="Lyrics"]`, `textarea[name*="lyric"]`, `[contenteditable="true"][aria-label*="Lyrics"]` |
| Create 按钮 | `createButton` | `button:has-text("Create")`, `button:has-text("Generate")`, `button[aria-label*="Create"]`, `[data-testid="create-button"]` |

### Playlist/Workspace 管理
| 元素 | 注册键 | 选择器 |
|------|--------|--------|
| 新建 Playlist | `newPlaylistButton` | `button:has-text("New Playlist")`, `button:has-text("Create Playlist")`, `button:has-text("New playlist")`, `button[aria-label*="new playlist"]` |
| Playlist 名称输入 | `playlistNameInput` | `input[placeholder*="Playlist"]`, `input[placeholder*="playlist"]`, `input[placeholder*="name"]`, `dialog input[type="text"]`, `[role="dialog"] input` |
| 确认按钮 | `playlistConfirmButton` | `button:has-text("Save")`, `button:has-text("Create")`, `button:has-text("OK")`, `[role="dialog"] button:has-text("Save")` |

---

## 选择器发现方法

当选择器失效时，运行发现模式：
```bash
node suno_browser.js --discover
```

这会打开 SUNO 页面并输出所有可交互元素的信息（tag、text、placeholder、aria-label、data-testid 等），据此更新上表和脚本中的 `SELECTOR_REGISTRY`。

---

## SUNO 页面结构备注

- **Create 页面 URL**: `https://suno.com/create`
- **Home 页面 URL**: `https://suno.com`
- Create 页面有两种模式：Simple（简单描述）和 Custom（自定义 Styles + Lyrics）
- Custom 模式下有 Instrumental 开关，开启后 Lyrics 区域隐藏或变灰
- Styles 和 Lyrics 可能是 `<textarea>` 或 `<div contenteditable="true">`，脚本需兼容两种
- Create 按钮点击后变为 disabled 状态，生成完成后恢复
- Playlist 在左侧边栏管理，创建时弹出 dialog 或内联输入框
