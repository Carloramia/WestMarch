# Example

## User Request

Describe a realistic request that should trigger this skill.

## Expected Behavior

Describe the expected output shape and key checks.

