# SUNO V2 — AI 音乐自动化创作

## What this skill does
完整的 SUNO AI 音乐创作工作流：收集音乐需求 → 分析提示词库生成 3 个音乐方向 → 用户确认 → Playwright 自动化在 SUNO 网站批量创建音乐。

**触发关键词**: SUNO 音乐创作、AI 音乐生成、SUNO 自动化、批量生成音乐、suno-v2

## Requirements
- Node.js (已安装)
- Playwright (通过 node_modules 可用)
- **Chrome 自动启动**（CDP 连接方式）：
  脚本会自动检测 9222 端口，如果 Chrome 未运行，会自动以调试端口启动：
  ```
  chrome.exe --remote-debugging-port=9222 --user-data-dir="%USERPROFILE%\chrome-debug-profile"
  ```
  脚本通过 `chromium.connectOverCDP("http://127.0.0.1:9222")` 连接到 Chrome 实例。
  如果系统找不到 Chrome（非标准安装路径），可设置环境变量 `CHROME_PATH` 指定路径。
  使用 CDP 是因为 Suno 会拦截 Playwright 自行启动的 Chrome，导致页面无法正常渲染。
- 提示词库 Excel（默认优先）: `references/互娱AI音乐关键词整合 (2).xlsx`
- 需求模板（仅参考，不作为自动输入源）:
  - `references/复杂音乐需求模板.xlsx`
  - `references/简单音乐需求模板.xlsx`

---

## Phase 1: 对话流程（LobsterAI 行为）

当此 skill 被触发时，Agent 按以下步骤执行。每个步骤必须完成后才能进入下一步。

> **路径约定**：下文中 `{SKILL_DIR}` 表示本 skill 的安装根目录（即包含 `manifest.json` 的目录）。
> 在 Sonus 共享安装中，通常为 `~/.sonus-assistant/skills/suno-v2/`。

### Step 1: 需求收集

向用户收集以下信息：

**必须项：**
- **需求来源**（二选一）：
  - 需求文档（文件路径，支持 `.docx` / `.xlsx` / `.txt` / `.md`）
  - 或关键词 + 定义（纯文本描述音乐需求）
- **需求名称**：如“战斗主题曲”“场景音乐”等

**可选项：**
- **项目编号**：如 `G78`、`H55`（英文字母+数字格式）。如无可留空

如果用户提供了文档，优先读取并提取关键信息：音乐风格、情绪、乐器、结构、时长、参考作品。

注意：每次创作都必须读取“用户本次提供的实际需求文档路径（或上传文件）”。
`references/复杂音乐需求模板.xlsx` 与 `references/简单音乐需求模板.xlsx` 仅用于填写参考，不可当作本次创作需求直接执行。

### Step 2: 提示词库分析

1. 读取 Excel 提示词库（优先顺序）：
   - 首选：`references/互娱AI音乐关键词整合 (2).xlsx`
   - 若不存在，再使用用户显式提供的外部路径
   - 参考 `references/excel_library_guide.md` 了解各 sheet 字段含义

2. 执行匹配（按优先级）：
   - **项目编号匹配**：如有项目编号，查 `内部项目关键词库` sheet，找到则以其提示词为基础
   - **风格匹配**：在 `可触发风格` 中搜索用户需求的中文关键词，提取英文风格标签
   - **乐器匹配**：在 `可触发乐器` 中搜索，提取英文乐器名
   - **方向/氛围匹配**：在 `方向关键词` 中搜索，提取英文情绪/氛围词
   - **参考匹配**（可选）：如用户提及作曲家或游戏/影视，查 `可触发作曲家` 或 `可触发游戏影视`

3. 汇总所有匹配到的英文关键词，去重备用

### Step 3: 生成 3 个方向

基于匹配结果，创建 **3 个差异化的音乐方向**，每个包含：

| 字段 | 说明 |
|------|------|
| 方向编号 | 1, 2, 3 |
| 方向名称 | 中文或英文名均可，但要表达方向特征 |
| 描述 | 1-2 句中文说明创意意图 |
| Styles 内容 | 实际粘贴到 SUNO `Styles` 字段的英文关键词，逗号分隔 |
| Lyrics 内容 | 歌曲类可填写结构化内容；BGM / 纯器乐通常留空 |

**差异化要求**：
- 3 个方向使用不同的**主乐器组合**
- 3 个方向有不同的**情绪走向**
- 3 个方向有不同的**风格融合方式**

### Step 4: 用户确认

与用户确认：
- 满意全部
- 修改某个方向
- 全部重新生成

如果需要修改：
- 单个方向：仅重生成该方向
- 全部重生成：重新执行 Step 2-3（最多 3 次）

### Step 5: 确认数量

向用户询问每个方向创作的音乐数量。

说明：SUNO 每次 `Create` 会生成 **2 首**。例如需要 6 首 = 3 次 `Create`。

收集完毕后，计算每个方向的 `createClicks = Math.ceil(数量 / 2)`。

### Step 5.5: 执行触发规则（避免二次确认）

当用户已明确确认“方向方案 + 生成数量”后，必须直接进入 Step 6 执行自动化。

- 不再追加“是否开始/是否执行”二次确认
- 默认行为：确认即执行
- 执行完成后直接返回 `shareLinks` 与 `shareMessage`

### Step 6: 执行自动化

#### 6.1 推荐配置结构（当前脚本原生支持）

```json
{
  "workspaceName": "{项目编号}-{需求名称}",
  "directions": [
    {
      "index": 1,
      "name": "方向名称",
      "styles": "styles 内容",
      "lyrics": "lyrics 内容或空字符串",
      "createClicks": 3
    }
  ]
}
```

- Workspace 命名：`{项目编号}-{需求名称}`，无项目编号则直接用 `{需求名称}`
- 当前脚本支持直接传 **JSON 字符串**，也支持传 **JSON 文件路径**

#### 6.2 兼容旧结构

如果历史配置仍使用旧版 `batches` 结构，脚本会自动转换为 `directions`，例如：

```json
{
  "workspace": "G00-战斗音乐",
  "batches": [
    {
      "direction": 1,
      "name": "方向1",
      "create_clicks": 2,
      "styles": "epic, orchestral",
      "lyrics": ""
    }
  ]
}
```

运行时会自动转换，不需要手工改旧文件。

#### 6.3 运行方式

**方式 A：直接传 JSON 文件路径（推荐）**

```bash
node "{SKILL_DIR}/scripts/suno_browser.js" --config "C:\path\to\config.json"
```

**方式 B：直接传 JSON 字符串**

```bash
node "{SKILL_DIR}/scripts/suno_browser.js" --config '{"workspaceName":"G78-战斗主题曲","directions":[{"index":1,"name":"方向1","styles":"epic, orchestral","lyrics":"","createClicks":2}]}'
```

#### 6.4 监控脚本输出

- `[SUNO_PROGRESS]` — 进度更新
- `[SUNO_LOGIN_REQUIRED]` — 需要用户在浏览器中手动登录
- `[SUNO_ERROR]` — 报告错误并诊断原因
- `[SUNO_COMPLETE]` — 自动化完成

### Step 7: 完成报告

自动化完成后，脚本会在 stdout 输出一行 `[SUNO_COMPLETE] <JSON>`。

**必须从该行解析 JSON，并向用户汇报 `shareLinks` 与 `shareMessage`。这是 Step 7 最重要的输出，不可省略。**

#### 7.1 解析 `[SUNO_COMPLETE]`

1. 在脚本 stdout 中找到以 `[SUNO_COMPLETE]` 开头的行
2. 提取该前缀之后的 JSON 字符串并解析
3. 关键字段：
   - `shareLinks`: `[{ title, shareUrl, rowIndex }, ...]` — 每首歌的分享链接
   - `shareMessage`: 已格式化好、可直接发给客户的试听文案

#### 7.2 向用户汇报

先输出结构化摘要：

- Workspace 名称
- 每个方向的 `Create` 次数、生成歌曲数、版本号范围
- 总歌曲数

然后输出 `shareMessage`（如果非空，原文直接展示，不要改写）：

```
请您试听以下版本，并回复您偏好的序号（可多选）：

1. G78-战斗主题曲-Version 1.1
https://suno.com/song/xxxxx

2. G78-战斗主题曲-Version 1.2
https://suno.com/song/yyyyy

如有修改意见，也欢迎直接告诉我（例如：节奏更强、情绪更温暖、人声更突出等）。
```

#### 7.3 当 shareLinks 为空时

如果 `shareLinks` 为空或缺失：
1. 明确告知用户"Share Link 收集失败"
2. 说明可手动运行以下命令补充收集：
   ```bash
   node "{SKILL_DIR}/scripts/suno_browser.js" --collect-share-only --limit <歌曲数>
   ```
3. **不要直接告知用户"自行前往 SUNO 查看"作为终态**，应主动提供补救步骤

---

## Phase 2: 自动化脚本参考

**脚本路径**: `{SKILL_DIR}/scripts/suno_browser.js`

### 运行模式

1. **创作模式**: `node suno_browser.js --config '<json>'`
2. **文件模式**: `node suno_browser.js --config "C:\path\to\config.json"`
3. **发现模式**: `node suno_browser.js --discover`
4. **仅抓取 Share Link 模式**: `node suno_browser.js --collect-share-only --limit 4`
5. **Excel 转 Suno 配置模式**: `node read_requirement_excel.js --file "<xlsx-path>" --mode suno-config --output "<config.json>"`

### 通用入口：Excel → JSON → SUNO → Share Link

当你只有需求 Excel（还没有 config.json）时，按以下两步跑：

```bash
node "{SKILL_DIR}/scripts/read_requirement_excel.js" --file "<需求Excel路径>" --mode suno-config --output "{SKILL_DIR}/tmp_config.json"
```

```bash
node "{SKILL_DIR}/scripts/suno_browser.js" --config "{SKILL_DIR}/tmp_config.json"
```

说明：
- `--mode suno-config` 会输出 `workspaceName + directions[]`，可直接喂给 `suno_browser.js`
- `directions` 解析优先读取表头中的方向/名称/styles/lyrics/数量/点击次数等字段
- 若无法识别结构，会生成一个兜底方向，保证流程可执行
- 最终 `suno_browser.js` 的 `[SUNO_COMPLETE]` 中会包含 `shareLinks` 与 `shareMessage`

### Share Link 模式说明

当你只想把当前页面已有歌曲的分享链接抓出来（不跑生成流程）时，使用：

```bash
node "{SKILL_DIR}/scripts/suno_browser.js" --collect-share-only --limit 4
```

- `--limit` 可选，表示抓取当前可见歌曲前 N 首，默认 4
- 脚本会执行：`...` → `Share` → `Copy Link`
- 最终在 `[SUNO_COMPLETE]` 返回：
  - `titles`
  - `shareLinks`（title/url 对）
  - `shareMessage`（可直接发客户的文本）

### 输出格式

| 前缀 | 含义 |
|------|------|
| `[SUNO_PROGRESS]` | 进度更新 |
| `[SUNO_INFO]` | 一般信息 |
| `[SUNO_ERROR]` | 错误（输出到 stderr） |
| `[SUNO_LOGIN_REQUIRED]` | 需要手动登录 |
| `[SUNO_COMPLETE]` | 完成，附带 JSON 报告 |

---

## BGM / 纯乐器规则

对于 **BGM、场景配乐、纯器乐** 需求：

- `lyrics` 建议留空字符串 `""`
- 原本准备写进 `Lyrics` 的结构、氛围、配器描述，优先合并进 `styles`
- 例如把“3/4、五声调式、伽倻琴、奚琴、民族打击乐、港口 admiration氛围”等信息直接组织进 `styles`

对于**歌曲类**需求，再考虑填写结构化 `lyrics`。

---

## 命名规则

| 项目 | 格式 | 示例 |
|------|------|------|
| Workspace | `{项目编号}-{需求名称}` | `G78-战斗主题曲` |
| 歌曲版本 | `{项目编号}-{需求名称}-Version {a}.{b}` | `G78-战斗主题曲-Version 1.3` |
| a | 方向编号 | `1 / 2 / 3` |
| b | 方向内连续版本号 | `1, 2, 3, 4...` |
| 无项目编号 | 直接用需求名称 | `战斗主题曲-Version 2.1` |

### 命名细则

- 同一次 `Create` 会生成 2 首，因此同一次点击会占用两个连续版本号
- 例如方向 1 第 1 次 `Create`：
  - `G48-韩国港口音乐-Version 1.1`
  - `G48-韩国港口音乐-Version 1.2`
- 方向 1 第 2 次 `Create`：
  - `G48-韩国港口音乐-Version 1.3`
  - `G48-韩国港口音乐-Version 1.4`
- 方向 2 会重新从 `2.1` 开始累计

---

## 错误处理

1. **选择器失败**：运行 `--discover` 模式查看当前页面元素，并更新 `references/suno_ui_selectors.md` 与脚本中的 `SELECTOR_REGISTRY`
2. **登录过期**：脚本会自动检测并输出 `[SUNO_LOGIN_REQUIRED]`
3. **积分不足**：`Create` 按钮可能处于 disabled 状态
4. **网络问题**：主要操作已带重试逻辑
5. **配置兼容性**：如果传入的是旧版 `batches` 结构，脚本会自动做转换