# Changelog

## 1.0.0

- 初始版本：从 LobsterAI suno-v2 skill 迁移至 Sonus 标准模板
- 支持对话式需求收集 + 提示词库匹配 + 多方向生成
- Playwright CDP 自动化批量创建音乐
- Excel 需求导入（read_requirement_excel.js）
- Share Link 批量收集模式
- 硬编码路径替换为通用 {SKILL_DIR} 变量
