---
name: creative-delivery-ops
description: Plan creative or game-content production with content matrices, asset standards, dependencies, owners, review gates and handoffs. Use for content planning and delivery tracking, not campaign copywriting, screenplay drafting or approval without evidence.
---

# Content Planning and Creative Delivery

Distinguish planning a production pipeline from producing its creative content.

## Modes

- Cross-discipline delivery or status tracking: use [the delivery board](assets/delivery-board-template.md); consult [the operations guide](references/creative-delivery-ops/guide.md) for details.
- Game-content matrices, asset tiers, capacity, tools and acceptance standards: read [content planning](references/content-planning/references/spec.json).

## Workflow

1. Establish outcome, deliverables, source material, real constraints, decision owner and review gates. Unknown owners and dates remain unassigned.
2. Link content categories and asset variants to actual production and review needs. Do not invent a version schedule or mandatory S/M/L/XL tiers unless the project uses them.
3. Give each task an observable output, owner or unassigned state, dependency and definition of done. Separate quantity estimates from commitments.
4. Track status, version, filename, location, format, rights dependencies and handoff destination. Keep approval distinct from production completion.
5. Surface blockers and next decisions. For updates, report changes since the last version rather than rewriting the whole plan.

Do not contact people, edit external boards, publish work or mark approval complete without the relevant authorization and evidence. Use the project's status vocabulary; the imported status list is a starting convention, not a universal replacement.
