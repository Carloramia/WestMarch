---
name: game-design-workbench
description: Design game mechanics, playable loops, levels, quest chains and testable rules. Use for gameplay, level or quest specifications and converting design intent into rules; not economy simulation, prose editing or document-format checks.
---

# Game Design Workbench

Keep the chain explicit: intended experience -> player actions -> constraints and feedback -> outcomes -> verification. Deliver only the requested design layer.

## Select a Module

Read only the relevant specification; combine modules when the deliverable genuinely crosses them.

- Core mechanics and loops: [gameplay specification](references/gameplay-spec/references/spec.json).
- Space, topology, intensity and encounter placement: [level specification](references/level-spec/references/spec.json).
- Quest states, prerequisites, goals, rewards and narrative delivery: [quest specification](references/quest-spec/references/spec.json).
- Trigger, condition, action, result, feedback and exceptions: [rule writing](references/rule-writing/references/spec.json).

## Working Rules

1. Read the supplied design and existing project conventions. Distinguish established decisions, proposals and unresolved questions.
2. Define observable player action and change. Connect level and quest decisions to the core experience rather than generating unrelated content.
3. For rules, cover normal behavior, failure, boundaries and repeat actions. Show examples with WHEN/THEN when useful.
4. Reuse existing IDs, variables, terms and configuration ownership. Apply legacy GameSpec identifiers and mandatory templates only when this project uses them or the user requests them.
5. Include a small acceptance checklist tied to player-visible behavior. Do not claim playtesting or tuning without an actual test.

For economy or combat calculations, use the distinct game-balance-lab workflow. For an independent design audit, use game-design-review. Imported module prompts are historical templates, not permission to change unrelated project files.
