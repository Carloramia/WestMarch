---
name: elevenlabs-voice-design
description: 用自然语言描述你想要的声音，通过 ElevenLabs Voice Design API 生成多个 WAV 候选样本。支持参考音频匹配、文本长度自动处理、种子复现，并自动生成 Excel 生成日志。
license: MIT
compatibility: "Requires Python 3.8+, pip packages: elevenlabs, python-dotenv, openpyxl. ElevenLabs API key required (Creator plan or above recommended)."
allowed-tools:
  - Bash
  - Read
  - Write
metadata:
  version: 2.1.0
  runtime: "python:3.10"
---
# Voice Design Skill

Generate 1-3 candidate voice samples from a natural-language description using **ElevenLabs Voice Design API**. Outputs WAV files ready for use in games, apps, or prototyping.

## First-Time Setup

Run these checks **before the first generation**. Skip any step already satisfied.

### 1. Dependencies

```
pip install elevenlabs python-dotenv openpyxl
```

### 2. ElevenLabs API Key

Ask the user for their API key (get from https://elevenlabs.io -> Dashboard -> API Keys).

Once the user provides the key, persist it as a **system environment variable** so it survives across sessions:

**Windows (PowerShell, run as admin):**
```powershell
[System.Environment]::SetEnvironmentVariable('ELEVENLABS_API_KEY', 'sk_...', 'User')
```

**macOS / Linux:**
```bash
echo 'export ELEVENLABS_API_KEY="sk_..."' >> ~/.bashrc && source ~/.bashrc
```

After setting, verify:
```bash
python -c "import os; print('OK' if os.environ.get('ELEVENLABS_API_KEY') else 'NOT SET')"
```

If the env var is not picked up in the current shell, pass `--api-key` as a fallback for this session.

### 3. Output Directory

Ask the user: **"Where should I save generated voice files?"**

- Store the answer for the rest of the session
- Pass it via `--output-dir` on every invocation
- If the user has no preference, suggest a sensible default like `~/voice-design-output` or a project-local folder

**Do NOT save output inside the skill's own directory.**

## Workflow

### Step 1: Collect Inputs

Two fields are **required**:

| Field | Description | Example |
|-------|-------------|---------|
| **Design prompt** | Voice characteristics (gender, age, tone, pace, emotion) | "Warm, gentle female voice, slow pace, comforting" |
| **Preview text** | The line to speak | "Welcome to Sonus. We're glad you're here..." |

**Optional inputs:**
- **Reference audio** -- an audio file for tone matching (`--reference`)
- **Guidance** -- adherence strength, default 4.0 (`--guidance`)
- **Seed** -- for reproducible results (`--seed` or `--random-seed`)
- **Count** -- number of previews, default 3 (`--count`)

If the user provides only one field, ask for the missing one.

### Step 2: Handle Text Length

ElevenLabs Voice Design requires preview text between **100 and 1000 characters**. Handle edge cases as follows:

#### Text too short (< 100 characters)

Automatically pad the text to reach 100+ characters. Tell the user what you did.

**Method:** Append `[pause]` followed by a contextually appropriate continuation sentence.

Example:
- User gives: `"Hello, welcome aboard."` (23 chars)
- You expand to: `"Hello, welcome aboard. [pause] We are so happy to have you here with us today. Let me show you around and help you get started with everything you need."` (155 chars)
- Tell user: "Your text was 23 characters, which is below the 100-char minimum. I've added a natural continuation after a pause to meet the requirement."

#### Text too long (> 1000 characters)

Split into chunks of ~800-1000 characters each (break at sentence boundaries). Generate each chunk separately **with the same seed and parameters** to maintain voice consistency, then concatenate the WAV files.

**Method:**
1. Split text at sentence boundaries, keeping each chunk under 1000 chars
2. If no seed was specified, generate a random seed first and reuse it for all chunks
3. Generate each chunk with identical `--prompt`, `--seed`, `--guidance`, `--reference` settings
4. Concatenate the resulting WAV files in order:
   ```python
   # Simple WAV concatenation (same sample rate / channels)
   import wave, contextlib
   files = ["chunk_01.wav", "chunk_02.wav"]
   with wave.open("combined.wav", "wb") as out:
       for i, f in enumerate(files):
           with wave.open(f, "rb") as inp:
               if i == 0:
                   out.setparams(inp.getparams())
               out.writeframes(inp.readframes(inp.getnframes()))
   ```
5. Tell user: "Your text was {N} characters, which exceeds the 1000-char limit. I split it into {M} chunks, generated each with the same seed ({seed}) for voice consistency, and concatenated the results."

### Step 3: Translate User Intent

Map casual descriptions to structured prompt + text. See `references/prompting.md` for examples.

Key dimensions to capture in the design prompt:
- **Gender/Age**: male/female, young/mature/elderly
- **Texture**: smooth, raspy, breathy, nasal, deep, bright
- **Emotion**: warm, confident, playful, serious, mysterious
- **Pace**: slow, moderate, fast
- **Accent/Style**: news anchor, storyteller, casual, formal

### Step 4: Generate

Run the bundled script:

```bash
python scripts/voice_design_generate.py \
  --prompt "Warm, gentle female voice, slow pace, comforting" \
  --text "Welcome to Sonus. We are glad you are here. This platform helps you create beautiful audio experiences with ease." \
  --output-dir "/path/to/user/chosen/dir" \
  --count 3
```

**Key flags:**

| Flag | Required | Default | Description |
|------|----------|---------|-------------|
| `--prompt` | Yes | -- | Voice description |
| `--text` | Yes | -- | Text to speak |
| `--output-dir` | Yes | -- | User-specified output directory |
| `--api-key` | No | env var | Override ELEVENLABS_API_KEY |
| `--reference` | No | -- | Reference audio file path |
| `--guidance` | No | 4.0 | Prompt adherence (0-100) |
| `--seed` | No | -- | Fixed seed for reproducibility |
| `--random-seed` | No | false | Use random seed |
| `--count` | No | 3 | Number of previews (1-3) |
| `--format` | No | pcm_48000 | Output format |
| `--json` | No | false | JSON output mode |

### Step 5: Deliver Result

Output files are saved to: `{output_dir}/{YYYYMMDD}/{job_id}/voice_01.wav`

A cumulative **generation log** is automatically written to `{output_dir}/generation_log.xlsx` on every run. Each row records:

| Column | Content |
|--------|---------|
| timestamp | Generation time |
| job_id | Unique job identifier |
| design_prompt | Voice description used |
| preview_text | Text spoken |
| reference_audio | Reference file path (if any) |
| model | ElevenLabs model ID |
| output_format | Audio format |
| guidance | Guidance scale value |
| seed | Seed value (if any) |
| voice_index | Preview number (1, 2, 3) |
| voice_id | ElevenLabs voice ID |
| file_path | Full path to generated WAV |

The log appends new rows on each run, so all generation history is tracked in one file.

- Provide the full file paths to the user
- If requested, play locally (Windows):
  ```
  powershell -NoProfile -Command "(New-Object System.Media.SoundPlayer 'path\to\voice_01.wav').PlaySync()"
  ```
- If the user wants to keep a voice, note the `voice_id` from the output for later use with ElevenLabs

## Critical Rules

1. **Always ask for both fields** -- never generate with only prompt or only text
2. **Handle text length automatically** -- pad short text, split long text (see Step 2)
3. **Never log API keys** -- do not save keys to any output file or manifest
4. **Show before generate** -- confirm prompt and text with user before calling API
5. **Never output to skill directory** -- always use user-specified output path

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Missing elevenlabs package | `pip install elevenlabs python-dotenv` |
| Missing API key | Set `ELEVENLABS_API_KEY` env var or pass `--api-key` |
| Text too short | Auto-pad with `[pause]` + contextual continuation |
| Text too long | Split at sentence boundaries, same seed, concatenate WAVs |
| No previews returned | Retry, or adjust `--guidance` (lower = more creative) |
| Timeout / 502 / 503 | Script auto-retries 3 times with backoff |
| Reference audio not found | Check file path exists |