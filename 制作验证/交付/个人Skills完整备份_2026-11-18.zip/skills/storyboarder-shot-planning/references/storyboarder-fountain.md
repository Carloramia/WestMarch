# Storyboarder / Fountain integration notes

Verified upstream references:

- Storyboarder repository: https://github.com/wonderunit/storyboarder
- Fountain parser: https://github.com/wonderunit/storyboarder/blob/master/src/js/fountain-data-parser.js
- Scene-ID insertion: https://github.com/wonderunit/storyboarder/blob/master/src/js/fountain-scene-id-util.js
- Multi-scene Fountain fixture: https://github.com/wonderunit/storyboarder/blob/master/test/fixtures/projects/multi-scene/multi-scene.fountain

Observed behavior from the source:

- Scene headings are parsed as scenes; action, dialogue, parentheticals, and transitions receive estimated timing.
- If a scene heading lacks an ID, Storyboarder inserts an ID shaped like `#<count>-<five characters>#`.
- Existing project fixtures use Fountain scene headings followed by IDs such as `#1-ZX3ZM#`.
- There is a reported compatibility issue involving some scene IDs containing dashes. For generated handoffs, keep IDs stable and simple unless the installed version has been tested with a different scheme.

The repository's top-level license metadata is non-standard and points to an EULA. Use source inspection for interoperability and do not copy or redistribute application code as though it were MIT/Apache licensed.

