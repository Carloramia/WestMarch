---
name: game-design-review
description: Review game or system design for intended experience, interaction, pacing, causal completeness, consistent definitions and boundary behavior. Use for design audits and logic reviews, not source-code security reviews or document-format-only validation.
---

# Game Design Review

Review the supplied design, not an imagined replacement. Findings lead; improvements remain proposals unless implementation was requested.

## Focus

- Experience, interaction, level flow and system fit: [design review](references/design-review/references/spec.json).
- Causality, state transitions, definitions, loops and edge cases: [logic review](references/logic-review/references/spec.json).

Read one or both according to the question, not by default.

## Output Standard

1. Identify the intended player experience and the actual evidence available.
2. For each real issue, record severity, source location, trigger, consequence and a concrete correction or verification step.
3. Distinguish contradiction, missing specification, hypothesis and validated failure. A missing detail is not automatically a defect.
4. Check repeated actions, state ownership, cancellation, save/load boundaries, failure feedback and incentives when relevant.
5. Avoid unsupported numeric grades and generic checklists. A legacy score rubric applies only when explicitly selected; otherwise report findings and residual uncertainty.

For numerical proof, hand off the specific hypothesis to game-balance-lab. For naming, template or document structure compliance alone, use docs-maintenance rather than expanding the review.
