---
name: screenplay-workbench
description: Develop or analyze screenplays, stories and game narrative, including premises, character goals, beat sheets, scene outlines, Fountain text and continuity. Use for story decomposition and narrative specifications; not camera shot planning or complete-work archiving.
---

# Screenplay and Narrative Workbench

Preserve the source's format, voice and established events. Separate source facts, supported interpretation, creative proposals and unresolved information.

## Workflow

1. Identify whether the task is story development, diagnosis, faithful decomposition or an explicit game-narrative handoff. Determine supplied coverage before claiming whole-story conclusions.
2. Trace premise -> character goal, obstacle and stakes -> scenes/sequences -> beats -> meaningful action and change. Infer immediate goals from clear behavior; do not invent hidden motives or deep needs.
3. Cut beats when strategy, information, relationship, risk or situation changes, not at every sentence. Identify their local function without forcing fixed acts, a hero journey or a minimum beat count onto excerpts.
4. Check causality, motivation, setup/payoff, escalation, pacing, point of view and continuity against specific scenes or quotes. Do not mistake simultaneous events for causation or reasonable silence for a defect.
5. If charting rise and fall, name the variable and viewpoint. Do not mix dramatic tension, emotional valence and character fortune on one axis. Keep score reasons and source anchors, preserve unknowns and distinguish discourse order from story chronology.
6. Keep transferable inspiration separate from source plot analysis. Mark new applications as proposals; do not silently add them to the original story.

## Formats and Modules

- Ordinary screenplay, outlines, diagnosis and beat sheets: use the workflow above; load [the original screenplay guide](references/screenplay-workbench/guide.md) only for additional format guidance.
- Explicit GameSpec narrative delivery: read [narrative specification](references/narrative-spec/references/spec.json). Its production template, philosophical-theme field and gameplay integration checks are conditional, not requirements for analyzing arbitrary material.
- Continuity: use [the editable bible](assets/continuity-bible-template.md) for time, location, knowledge, relationships, props, injuries, promises and unresolved threads.
- Fountain: preserve standard scene headings, playable action, character cues and separate dialogue lines.

Return only the requested artifacts. Keep story structure and evidence concise, and keep shot-by-shot camera planning in storyboarder-shot-planning.
