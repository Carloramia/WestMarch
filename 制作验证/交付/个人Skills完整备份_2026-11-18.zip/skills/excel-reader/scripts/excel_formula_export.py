
"""
excel_formula_export.py — Excel 公式层提取工具

与 excel_export.py 配套使用，专门提取公式 + 数据源链路。

输出：
    {tag}_export/
        ├── formulas.json          # 每个有值cell的公式/值/引用链路
        └── formula_summary.md     # 人可读的公式摘要（按sheet分组，高亮锚点）

使用方式：
    python excel_formula_export.py <input.xlsx> --tag <tag> [--sheets "sheet1" "sheet2"]
    python excel_formula_export.py <input.xlsx> --tag <tag> --all-sheets

输出格式（formulas.json）:
    {
      "SheetName": {
        "A3": {
          "formula": "=G51",
          "value": null,          // data_only=True时的计算值，None=无法读取
          "refs_to": ["G51"],     // 直接引用的cells（同sheet，不含跨sheet）
          "xrefs_to": [           // 跨sheet引用
            {"sheet": "24-25LTV趋势-M", "cell": "J29"}
          ],
          "category": "ref",      // ref / arith / const / empty
          "is_hardcoded": false
        }
      }
    }
"""

import sys
import re
import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional

try:
    import openpyxl
    from openpyxl.utils import get_column_letter, column_index_from_string
except ImportError:
    print("ERROR: openpyxl not installed. Run: pip install openpyxl")
    sys.exit(1)


# ─────────────────────────────────────────────
# 公式解析：提取引用的 cells
# ─────────────────────────────────────────────

# 跨sheet引用 pattern：'SheetName'!A1 或 SheetName!A1
XREF_PATTERN = re.compile(
    r"'([^']+)'!(\$?[A-Za-z]+\$?\d+)"   # 带引号sheet名
    r"|([A-Za-z0-9_\-]+)!(\$?[A-Za-z]+\$?\d+)"  # 不带引号sheet名
)
# 同sheet引用 pattern：$A$1 / A1 / A$1 / $A1
CELL_PATTERN = re.compile(r'\$?([A-Za-z]{1,3})\$?(\d+)')


def _normalize_cell(ref: str) -> str:
    """去掉 $ 符号，统一为 A1 格式"""
    return ref.replace('$', '')


# ─────────────────────────────────────────────
# 隐藏行/列工具（与隐藏 Sheet 逻辑对称）
# ─────────────────────────────────────────────

def _build_hidden_sets(ws) -> tuple:
    """
    返回 (hidden_rows: set[int], hidden_cols: set[int])
    隐藏行/列的编号集合（1-based），用于过滤迭代时跳过不可见单元格。
    与 sheet_state 过滤隐藏 Sheet 的逻辑完全对称。
    """
    hidden_rows = set()
    for row_idx, rd in ws.row_dimensions.items():
        if rd.hidden:
            hidden_rows.add(row_idx)

    hidden_cols = set()
    for col_letter, cd in ws.column_dimensions.items():
        if cd.hidden:
            try:
                hidden_cols.add(column_index_from_string(col_letter))
            except Exception:
                pass

    return hidden_rows, hidden_cols


def parse_formula_refs(formula: str, sheet_name: str) -> Tuple[List[str], List[dict]]:
    """
    解析公式，返回 (同sheet引用列表, 跨sheet引用列表)
    """
    if not formula or not formula.startswith('='):
        return [], []

    same_sheet_refs = []
    cross_sheet_refs = []

    # 先提取跨sheet引用，并从formula中移除，避免被同sheet pattern误匹配
    formula_remaining = formula

    for m in XREF_PATTERN.finditer(formula):
        if m.group(1):
            sname, cref = m.group(1), m.group(2)
        else:
            sname, cref = m.group(3), m.group(4)
        cross_sheet_refs.append({"sheet": sname, "cell": _normalize_cell(cref)})
        formula_remaining = formula_remaining.replace(m.group(0), '')

    # 同sheet引用
    seen = set()
    for m in CELL_PATTERN.finditer(formula_remaining):
        col_str, row_str = m.group(1), m.group(2)
        # 过滤掉函数名（全大写且不像cell地址）
        ref = f"{col_str.upper()}{row_str}"
        if ref not in seen:
            seen.add(ref)
            same_sheet_refs.append(ref)

    return same_sheet_refs, cross_sheet_refs


def categorize_cell(value) -> Tuple[str, bool]:
    """
    返回 (category, is_hardcoded)
    category: 'formula' / 'const' / 'empty'
    """
    if value is None:
        return 'empty', False
    if isinstance(value, str) and value.startswith('='):
        return 'formula', False
    # 非公式的有值cell = 硬编码常量
    return 'const', True


# ─────────────────────────────────────────────
# 主提取逻辑
# ─────────────────────────────────────────────

def extract_sheet_formulas(ws_formula, ws_value) -> Dict[str, dict]:
    """
    提取一个sheet的所有cell信息。
    ws_formula: data_only=False（含公式字符串）
    ws_value:   data_only=True（含Excel计算后的值）

    隐藏行/列与隐藏 Sheet 逻辑对称：自动跳过，AI 眼中不存在。
    """
    result = {}

    # 构建隐藏行/列集合（以公式 sheet 为准）
    hidden_rows, hidden_cols = _build_hidden_sets(ws_formula)
    if hidden_rows or hidden_cols:
        print(f"    [过滤] 隐藏行: {sorted(hidden_rows)}, 隐藏列idx: {sorted(hidden_cols)}")

    # 先从 data_only=True 建立值索引
    value_index = {}
    for row in ws_value.iter_rows():
        for cell in row:
            if cell.row in hidden_rows or cell.column in hidden_cols:
                continue
            coord = cell.coordinate.replace('$', '')
            value_index[coord] = cell.value

    for row in ws_formula.iter_rows():
        for cell in row:
            # 跳过隐藏行/列
            if cell.row in hidden_rows or cell.column in hidden_cols:
                continue
            v = cell.value
            if v is None:
                continue

            coord = cell.coordinate.replace('$', '')
            category, is_hardcoded = categorize_cell(v)
            computed = value_index.get(coord)

            if category == 'formula':
                same_refs, cross_refs = parse_formula_refs(str(v), ws_formula.title)
                # 序列化计算值（datetime等需要转str）
                if computed is not None and not isinstance(computed, (int, float, str, bool)):
                    computed = str(computed)
                elif isinstance(computed, float):
                    computed = round(computed, 6)
                result[coord] = {
                    "formula": str(v),
                    "value": computed,       # Excel计算后的值，None=缓存未命中
                    "refs_to": same_refs,
                    "xrefs_to": cross_refs,
                    "category": "formula",
                    "is_hardcoded": False,
                }
            else:
                val = v if not isinstance(v, float) else round(v, 6)
                if val is not None and not isinstance(val, (int, float, str, bool)):
                    val = str(val)
                result[coord] = {
                    "formula": None,
                    "value": val,
                    "refs_to": [],
                    "xrefs_to": [],
                    "category": "const",
                    "is_hardcoded": True,
                }

    return result


def build_reverse_index(sheet_data: Dict[str, dict]) -> Dict[str, List[str]]:
    """构建反向引用索引：哪些cells引用了某个cell"""
    refs_by = {}
    for coord, info in sheet_data.items():
        for ref in info.get('refs_to', []):
            refs_by.setdefault(ref, []).append(coord)
    return refs_by


# ─────────────────────────────────────────────
# 摘要报告生成
# ─────────────────────────────────────────────

def generate_summary_md(all_data: Dict[str, Dict], wb_path: str) -> str:
    """生成 formula_summary.md"""
    lines = [
        f"# Excel 公式层摘要",
        f"",
        f"源文件：`{Path(wb_path).name}`",
        f"",
    ]

    for sheet_name, sheet_data in all_data.items():
        lines.append(f"## Sheet: {sheet_name}")
        lines.append("")

        formulas = {k: v for k, v in sheet_data.items() if v['category'] == 'formula'}
        consts = {k: v for k, v in sheet_data.items() if v['is_hardcoded']}
        xref_cells = {k: v for k, v in sheet_data.items()
                      if v.get('xrefs_to')}

        lines.append(f"- 总Cell数（有值）: {len(sheet_data)}")
        lines.append(f"- 公式Cell数: {len(formulas)}")
        lines.append(f"- 硬编码常量数: {len(consts)}")
        lines.append(f"- 跨Sheet引用数: {len(xref_cells)}")
        lines.append("")

        # 硬编码常量列表（潜在的手动更新点）
        if consts:
            lines.append("### 🔴 硬编码常量（潜在手动更新点）")
            lines.append("")
            lines.append("| Cell | 值 |")
            lines.append("|------|-----|")
            for coord, info in sorted(consts.items()):
                val = info.get('value', info.get('formula', ''))
                lines.append(f"| {coord} | `{val}` |")
            lines.append("")

        # 跨Sheet引用
        if xref_cells:
            lines.append("### 🔗 跨Sheet引用")
            lines.append("")
            lines.append("| Cell | 公式 | 引用来源 |")
            lines.append("|------|------|---------|")
            for coord, info in sorted(xref_cells.items()):
                xrefs = info.get('xrefs_to', [])
                xref_str = ', '.join(f"`{x['sheet']}!{x['cell']}`" for x in xrefs)
                lines.append(f"| {coord} | `{info['formula']}` | {xref_str} |")
            lines.append("")

        lines.append("---")
        lines.append("")

    return '\n'.join(lines)


# ─────────────────────────────────────────────
# CLI 入口
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Excel 公式层提取工具")
    parser.add_argument("input", help="Excel 文件路径")
    parser.add_argument("--tag", required=True, help="输出目录 tag（如 v46_calc）")
    parser.add_argument("--sheets", nargs="+", help="要提取的 sheet 名称（空格分隔）")
    parser.add_argument("--all-sheets", action="store_true", help="提取所有 sheet")
    parser.add_argument("--output-dir", help="输出目录（默认：与xlsx同级）")
    args = parser.parse_args()

    xlsx_path = Path(args.input).resolve()
    if not xlsx_path.exists():
        print(f"ERROR: 文件不存在：{xlsx_path}")
        sys.exit(1)

    # 输出目录
    if args.output_dir:
        out_dir = Path(args.output_dir) / f"{args.tag}_formula_export"
    else:
        out_dir = xlsx_path.parent / f"{args.tag}_formula_export"
    out_dir.mkdir(parents=True, exist_ok=True)

    # 两次加载：一次保留公式，一次读计算值
    print(f"Loading (formulas): {xlsx_path}")
    wb_f = openpyxl.load_workbook(str(xlsx_path), data_only=False)
    print(f"Loading (values):   {xlsx_path}")
    wb_v = openpyxl.load_workbook(str(xlsx_path), data_only=True)

    # 过滤隐藏 sheet（用户看不到的表不处理）
    hidden_sheets = [s for s in wb_f.sheetnames if wb_f[s].sheet_state != 'visible']
    visible_sheets = [s for s in wb_f.sheetnames if s not in hidden_sheets]
    if hidden_sheets:
        print(f"跳过隐藏工作表: {', '.join(hidden_sheets)}")

    # 确定要处理的 sheets
    if args.all_sheets:
        target_sheets = visible_sheets
    elif args.sheets:
        target_sheets = args.sheets
    else:
        print(f"Available sheets: {visible_sheets}")
        print("请用 --sheets 指定 sheet 名，或用 --all-sheets 处理全部")
        sys.exit(1)

    # 提取
    all_data = {}
    for sname in target_sheets:
        if sname not in wb_f.sheetnames:
            print(f"WARNING: Sheet '{sname}' 不存在，跳过")
            continue
        print(f"Processing sheet: {sname}")
        ws_f = wb_f[sname]
        ws_v = wb_v[sname]
        sheet_data = extract_sheet_formulas(ws_f, ws_v)
        # 加入反向索引
        refs_by = build_reverse_index(sheet_data)
        for coord in sheet_data:
            sheet_data[coord]['refs_by'] = refs_by.get(coord, [])
        all_data[sname] = sheet_data
        print(f"  → {len(sheet_data)} cells")

    # 写 formulas.json
    json_path = out_dir / "formulas.json"
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n✅ formulas.json → {json_path}")

    # 写 formula_summary.md
    md_path = out_dir / "formula_summary.md"
    md = generate_summary_md(all_data, str(xlsx_path))
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(md)
    print(f"✅ formula_summary.md → {md_path}")

    print(f"\nDone. 输出目录：{out_dir}")


if __name__ == "__main__":
    main()
