---
name: storyboarder-shot-planning
description: Convert screenplay scenes or Fountain text into shot lists and Storyboarder-ready handoff material, checking shot size, camera position, screen direction, eyelines, action continuity, duration, and scene identifiers. Use when planning or reviewing boards for Wonder Unit Storyboarder; do not claim to draw boards or modify a Storyboarder project unless files are provided and editing is requested.
---

# Storyboarder shot planning

Create a shot plan that an artist can board and that can be traced back to the script.

## Source handling

- Preserve the script's scene order and scene identifiers.
- If delivering Fountain for Storyboarder, give every scene heading a stable scene number in `#...#`. Prefer simple IDs without embedded dashes when compatibility is uncertain.
- Storyboarder can open Fountain screenplays. Treat the Fountain file as the script source and the `.storyboarder` project as the visual board project; do not promise lossless round-tripping.
- Read [Storyboarder and Fountain notes](references/storyboarder-fountain.md) before editing project files or designing automation.

## Shot planning

For each shot specify: shot ID, source beat or line, framing/shot size, subject and action, camera position/angle, movement, lens only when meaningful, estimated duration, dialogue/audio cue, transition, and continuity notes.

Check:

1. Establishing geography before spatially complex coverage.
2. Screen direction, 180-degree line, eyeline match, look room, action match, and entrances/exits.
3. Coverage sufficiency for dialogue, reveals, inserts, reactions, and edit points.
4. Whether every camera move communicates information or emotion rather than decorating the plan.
5. Whether shot count and duration fit the intended pace and production budget.

Use [the CSV template](assets/shot-list-template.csv) when a sheet-compatible handoff is useful. Flag risky continuity choices; do not silently normalize intentional jump cuts or axis breaks.

