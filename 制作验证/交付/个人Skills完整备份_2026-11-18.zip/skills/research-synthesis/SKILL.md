---
name: research-synthesis
description: Synthesize multiple published sources or raw user interviews into evidence-tagged themes, disagreements, confidence and decision implications. Use for research synthesis and interview affinity mapping, not a source-by-source summary or a full experimental research program.
---

# Research and Interview Synthesis

Choose the evidence mode before drawing conclusions. Mixed inputs must keep participant observations distinct from published claims.

## Source Synthesis

Read [the source-synthesis method](references/research-synthesis/guide.md) when combining articles, reports or other documents.

- Extract atomic claims with source, evidence type, context and confidence.
- Cluster across sources by meaningful propositions, not document order.
- Surface disagreements, independent corroboration, weakly repeated claims and unanswered questions.
- Weight evidence quality and applicability rather than counting mentions as truth.
- End with what the evidence implies for the actual decision, and what remains uncertain.

## Interview Synthesis

Read [the interview method](references/interview-synthesis/guide.md) for transcripts and participant notes.

- First extract observations with participant IDs and exact quotes; interpret only after affinity mapping.
- Cluster behavior or friction, not interview question numbers. Preserve disconfirming observations and outliers.
- Show participant coverage as n/N, confidence with its basis and available saturation evidence. Distinguish a single-person signal from a recurring theme.
- Small or incomplete samples can yield tentative findings, not fabricated saturation or broad generalization. Anonymize externally shared material.

## Delivery and Boundaries

Provide a concise decision-ready synthesis, supporting themes, tensions, limitations and provenance. Do not manufacture quotes, interviews or sources to satisfy a template.

Keep formal literature-review requirements when explicitly requested. Use research-lab for an iterative evidence/experiment/implementation program rather than forcing that heavyweight workflow onto an ordinary synthesis. Historical guides may mention optional skills that are not installed; do not assume they exist or require them to finish this workflow.
