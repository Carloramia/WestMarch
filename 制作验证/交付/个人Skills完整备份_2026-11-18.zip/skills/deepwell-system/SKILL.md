---
name: deepwell-system
description: Work on the Deepwell/深井 inspiration inventory system in E:\codex\内容文件\02_作品\项目\深井. Use when the user asks to continue, design, validate, improve, research, refactor, or extend 深井, including association graph, search, tagging, AI enrichment, Tencent Docs import, backup/export, PDF intake, launcher, UI readability, or stage acceptance work.
---

# Deepwell System

## First Moves

1. Work in `E:\codex\内容文件\02_作品\项目\深井`; the app is in `app`.
2. Read `app/README.md`, `03_深井系统_分类体系v1.md`, `04_深井系统_设计原则与长期需求.md`, and the latest acceptance/status document before changing behavior.
3. Check service health at `http://127.0.0.1:48170/api/health`.
4. Check database counts before risky work:
   - active items: `items where deleted_at is null`
   - soft-deleted items: `items where deleted_at is not null`
5. Do not restore, purge, or rewrite soft-deleted rows unless the user explicitly asks.

## Product Rules

- Deepwell stores inspiration atoms, knowledge-type inspirations, excerpts, questions, and references. It is not a finished-work or deliverable archive.
- Complete works can later be sources for decomposition, but ordinary inventory entries should remain small reusable inspiration units.
- User original text, user title, user tags, and user domains are authoritative.
- AI output must be clearly separate from user content and treated as unverified unless backed by sources.
- AI enrichment should add value beyond the user text; avoid repeating, summarizing, or paraphrasing the original as if it were new information.
- Prioritize storage, retrieval, readability, and concise scanning before exhaustive detail.

## Implementation Priorities

Prefer changes that improve:

1. Reliable capture and no data loss.
2. Retrieval quality and visible match reasons.
3. Readable scanning in inventory/search cards.
4. Association usefulness without dense line clutter.
5. Export, backup, and migration readiness.
6. Mobile/narrow-screen usability.

Avoid adding finished-work showcase, publishing, project delivery management, or heavy ontology features unless requested.

## Local Validation

Use the checklist in `references/acceptance-checklist.md` for stage acceptance.

Minimum validation for most app changes:

- `E:\node.exe --check app\src\server.js`
- `E:\node.exe --check app\public\app.js`
- `E:\node.exe --check app\src\launcher.js`
- Restart only the process listening on port `48170` when server code changed.
- Verify `/api/health`.
- Verify active and soft-deleted item counts did not change unexpectedly.
- Use browser checks for UI changes on desktop and narrow mobile widths.

## GitHub References

Use local references under `参考\github` before new web research:

- `cytoscape.js`: graph visualization and analysis.
- `radix-colors`: accessible color tokens.
- `electric`: future Postgres sync architecture.
- `automerge`: future multi-client conflict handling.

Do not introduce these libraries into `app` just because they are downloaded. First decide whether the current prototype needs the dependency.

## Association Graph Guidance

When improving related inspiration:

- Avoid showing all candidate edges at once.
- Prefer selected-node focus, strength threshold controls, and readable relation lists.
- Treat shared collection/domain as broad signals; require additional evidence such as primary tags, facets, or keywords.
- Keep reasons human-readable: shared collection, domain, primary tag, secondary tag, facet, keyword.
- Verify graph line count and node count in browser; the graph should help exploration, not become a dense mesh.

## Data Safety

- The SQLite database is at `app\data\deepwell.sqlite`; WAL files may be present.
- Backups live under `app\data\backups`.
- Prefer additive migrations using `CREATE TABLE IF NOT EXISTS` and `ALTER TABLE` guarded by `PRAGMA table_info`.
- Record snapshots before destructive or hiding operations when possible.
- Never log API keys, account tokens, private credentials, or full unnecessary personal data.
