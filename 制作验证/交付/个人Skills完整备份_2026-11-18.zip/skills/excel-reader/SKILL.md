---
name: excel-reader
description: "Excel 理解层 Skill：将任意 Excel 文件（策划文档/数据报告/配置表/混合内容）转化为结构化中间表示 data.md，供下游分析或格式化 Skill 消费。四通道提取：文本结构（openpyxl）、富文本格式（HTML通道）、视觉内容（按需截图）、公式血缘（formula_export）；并通过 🤖[AI] 标注识别颜色语义、废弃内容、待定标记等业务信号。支持子表 Schema 提取与跨区块数据一致性验证。本 Skill 只负责「读懂」，不负责「写出」。"
metadata:
  version: "2.0.0"
  upstream: ~
  downstream: ~
---

# Excel Reader Skill

## 〇、核心约束 ⚠️

1. **原始内容零修改**：MUST NOT 增删改原始内容
2. **🤖[AI] 标注**：Agent 补充内容 MUST 以 `🤖[AI]` 前缀标注
3. openpyxl 是文本提取的主通道；截图通道仅用于 openpyxl 无法读取的嵌入图片和视觉区域（如图片内文字需逐字转录，但不是对整表做 OCR）
4. **本 Skill 的终态输出是 data.md（+ 可选截图），不生成最终格式化文档**
5. 发现疑似错误可用 `🤖[AI]` 提问，MUST NOT 改原值

---

## 一、平台适配

| 环境 | HTML 通道 | 截图通道 |
|------|-----------|----------|
| Windows + Excel | win32com ✅ | win32com ✅ |
| macOS + Excel | 🚧 待实现 | 🚧 待实现 |
| Linux / macOS 无 Excel | LibreOffice headless ✅ | LibreOffice PDF → pdf2image ✅ |

- **HTML 通道**：`excel_export.py` 自动检测平台，优先使用 win32com（通道A），否则降级为 LibreOffice headless（通道B）。
- **截图通道**：Windows 用 win32com 剪贴板截图；Linux/macOS 用 LibreOffice → PDF → pdf2image → PIL 行范围裁剪。两者接口相同，自动切换。
- **openpyxl 格式通道**（字体颜色/背景色/加粗/删除线）：全平台可用，作为 HTML 通道的格式补充。
- **Linux 额外依赖**：见 `requirements.txt`
  ```bash
  apt install libreoffice poppler-utils   # 系统包
  pip install -r requirements.txt         # Python 包
  ```

---

## 二、运行模式

| 模式 | 说明 | 输出产物 | 流程 |
|------|------|----------|------|
| **完整模式（推荐）** | 文本提取 + 按需精细截图，信息最完整 | data.md + images/ | Step 0 → 1 → 2 |
| **轻量模式** | 仅文本提取，跳过截图，速度快 | data.md only | Step 0 → 1 |

轻量模式差异：
- **跳过 Step 2**：不执行截图
- data.md 中 `📷 *嵌入图片*` 标记保留为文本占位，不附带截图文件
- 颜色/格式语义的 `🤖[AI]` 标注正常输出（不依赖截图）

---

## 三、并行处理规则 ⚠️

Step 2 中多 sheet **无依赖关系**，**MUST 并行 subagent 处理**：
- Step 2（仅完整模式）：每 sheet 一个 `explore` subagent（分析 data.md + 按需截图）

每个 subagent prompt MUST 包含：
- 该 sheet 的 data.md 路径
- `references/enrichment_guidelines.md` 路径
- **当前运行模式（完整/轻量）**

---

## 四、工作流程

### Step 0: 准备

1. 获取 sheet 列表：
   ```bash
   python scripts/excel_range_screenshot.py "<excel_path>" dummy --list-sheets
   ```
2. **AskUserQuestion** 多选 sheet
3. **AskUserQuestion** 获取 ASCII tag（如 `dau_report_20260320`）
4. **AskUserQuestion** 选择运行模式：
   - **完整模式（推荐）**：含精细截图，图片/色阶/低置信表格均有视觉信息
   - **轻量模式**：跳过截图，仅文本结构，速度更快
   - 用户无响应时默认使用**完整模式**
5. 输出目录：`{excel所在目录}/{tag}_export/`

---

### Step 1: 结构化数据提取

```bash
python scripts/excel_export.py "<excel_path>" --tag "<tag>" --sheets "sheet名1" "sheet名2"
```

双通道并行提取（**不截图**）：
- **openpyxl 通道**：文本 + 边界 + 校验值 + 批注 + 条件格式 + 超链接
- **HTML 通道**：COM 导出 → CSS 解析 → 富文本格式（加粗/斜体/删除线/颜色/边框等）

内置增量机制（`.export_manifest.json` 校验值），重复运行自动跳过未变化 sheet。HTML 通道失败自动降级为单通道。

> ⚠️ 文件名/目录名 MUST ASCII。数据目录命名: `sheet_01_data`, `sheet_02_data`, ...。`sheet_mapping.json` 记录中文名↔目录名映射。

每个 sheet 生成 `sheet_NN_data/data.md`，包含：
- 表格检测（✅高置信/⚠️中置信/🟡疑似）+ 高置信区域自动转 Markdown 表格
- 富文本 HTML 标签（`<del>` `<strong>` `<font color>` 等）+ 💬批注 + 🎨条件格式 + 🔗超链接
- 非表格区域缩进文本树 + 📷 嵌入图片标记（含位置和尺寸）
- 超链接以 `[显示文本](链接目标)` 内联保留，`🔗 超链接摘要` 节汇总所有链接

> ✅ **通行条件**：每个选中 sheet 都已生成 data.md

---

### Step 2: 语义分析 + 按需截图（仅完整模式）

> ⚠️ **轻量模式跳过此步骤**，Step 1 完成即为终态。

读 data.md → 识别语义信号 → 规划截图区域 → 执行截图 → **读取截图，将视觉内容以 `🤖[AI]` 标注写回 data.md**。

⚠️ subagent MUST 先读取 `references/enrichment_guidelines.md`，按其中的信号表、语义分析规则和截图转录要求执行。

**截图决策信号**（详见 enrichment_guidelines.md）：

| 信号 | 截图决策 |
|------|----------|
| `📷 *嵌入图片*` 标记 | **MUST 截图** |
| `⚠️ 中置信` / `🟡 疑似` 表格 | **SHOULD 截图** |
| 🎨 `dataBar` / `colorScale` / `iconSet` 条件格式 | **SHOULD 截图** |
| 🔍 结构异常区域：数据流断裂、加粗非表头行、背景色突变、汇总关键词、数值极值 | **SHOULD 截图** |
| ✅ 高置信表格 / 💬 批注 / 纯文本 | 不需要截图 |

**区域规划原则**：
- 间隔 ≤20 行的信号合并为一个 zone
- 每 zone 上下扩 2-3 行上下文
- 每 sheet ≤5 zone；单 zone >50 行则拆分

截图工具调用示例：
```bash
# 批量截图（推荐）
python scripts/excel_range_screenshot.py "<excel_path>" "<sheet_name>" \
  --batch "<output_dir>/sheet_NN_data/sheet_NN_ranges.json" \
  --output-dir "<output_dir>/images/sheet_NN/"
```

> ✅ **通行条件**：需截图的区域已完成，截图已读取，视觉内容已以 `🤖[AI]` 标注写回各 sheet 的 data.md

---

## 五、容错

| 场景 | 处理 |
|------|------|
| HTML 通道失败 | 自动降级为 openpyxl 单通道，在 data.md 头部注明 |
| 截图失败 | data.md 对应位置注明 `📷 截图失败（原因）` |
| Excel 打开失败 | 报错终止，提示检查文件路径和 Excel 版本 |

---

## 六、公式层提取（默认随 excel_export.py 一起跑）

**读任何业务 Excel 时，必须同时跑 `excel_formula_export.py`**，不需要用户单独提醒。

```bash
# Step 1：值 + 格式（原有）
python scripts/excel_export.py "<excel_path>" --tag "<tag>" --sheets "Sheet1"

# Step 2：公式 + 值 + 引用链路（必须同时跑）
python scripts/excel_formula_export.py "<excel_path>" \
  --tag "<tag>" \
  --sheets "Sheet1" "Sheet2"   # 或 --all-sheets
```

**输出：**

| 文件 | 内容 | 如何使用 |
|------|------|---------|
| `{tag}_formula_export/formulas.json` | 每个 cell 的公式 + 计算值 + refs_to/xrefs_to/refs_by | grep 精准定位，不全量读 |
| `{tag}_formula_export/formula_summary.md` | 硬编码常量表 + 跨Sheet引用表 | 人工 review 或我快速扫 |

**JSON 结构（每个 cell 同时含公式和计算值）：**
```json
{
  "SheetName": {
    "R37": {
      "formula": "=L37/$I37",
      "value": 1.498198,
      "refs_to": ["L37", "I37"],
      "xrefs_to": [],
      "refs_by": [],
      "category": "formula",
      "is_hardcoded": false
    },
    "C29": {
      "formula": null,
      "value": 3.27,
      "refs_to": [], "xrefs_to": [], "refs_by": ["J29"],
      "category": "const",
      "is_hardcoded": true
    }
  }
}
```

**查询方式（不全量读，用 grep）：**
```bash
# 查某个 cell
python -c "import json; d=json.load(open('formulas.json',encoding='utf-8')); print(d['Sheet']['R37'])"

# 找所有跨Sheet引用
python -c "import json; d=json.load(open('formulas.json',encoding='utf-8')); [print(k,v['xrefs_to']) for k,v in d['Sheet'].items() if v.get('xrefs_to')]"
```

**硬编码常量 = 每次更新报告需要人工填写的输入点（重点关注）**
**跨Sheet引用 = 数据流的跨表依赖（更新某 Sheet 时追踪下游影响）**

---

## 七、子表 Schema 提取（按需，辅助公式语义化）

一个 Sheet 里往往包含多张**语义独立的子表**（用空行 / 标题行 / 背景色分隔）。当需要理解"某列在这张子表里叫什么"时（尤其是追公式时发现 F 列含义不明），运行此脚本建立 cell → 子表语义名映射。

> ⚠️ 这是**按需工具**，不是每次必跑。只在公式追溯遇到"列含义不确定"时触发。

```bash
python scripts/excel_table_schema.py "<excel_path>" --tag "<tag>" [--sheets "S1" "S2"]
# 或处理所有 sheet：
python scripts/excel_table_schema.py "<excel_path>" --tag "<tag>" --all-sheets
```

**输出：**

| 文件 | 内容 |
|------|------|
| `{tag}_export/sheet_NN_data/table_schema.json` | 每个子表的列头列表 + cell → (子表名, 列语义名, 相对行号) 映射 |
| `{tag}_export/table_schema_summary.md` | 人类可读的子表边界摘要 |

**典型用途**：

```
场景：追 formulas.json 发现 F37 被大量引用，但 F 列含义不明
操作：查 table_schema.json → F 列在该子表的列头是"总曝光"
结论：F37 = 总曝光，不是其他子表里的"转化数"（跨子表列含义不能互推）
```

> ⚠️ **列含义是子表局部的**，同一张 Sheet 中 F 列在不同子表含义完全不同，绝对不能跨子表推断。

---

## 八、数据差异分析规则 ⚠️（先追公式，后说结论）

> **核心原则：Hypothesis ≠ Conclusion。有公式可追时，禁止用推测回答数据差异问题。**

当发现 Excel 内某值与外部数据源（如数易/DataEase）不一致时，**MUST 按以下顺序处理，不得跳步**：

### 强制流程

```
Step 1: 定位 cell 坐标（如 F4）
Step 2: 查 formulas.json 确认 formula 字段
  - 若是公式 → Step 3
  - 若是硬编码常量 → Step 4
Step 3: 追公式链路（refs_to / xrefs_to），逐层展开直到找到口径定义
  例：F4 = C4 + D4 → C4 是新增账号，D4 是"15天回流"
Step 4: 用公式定义的口径解释差异
  例："引流量表的总引入 = 新增 + 15天回流，而数易只统计新增，因此口径不同导致数值差异"
```

### 禁止行为

| ❌ 禁止 | ✅ 替代 |
|--------|--------|
| "可能是口径问题，你知道为什么吗？" | 先查 `formulas.json` 找到公式定义，证明了再说结论 |
| "数据来源可能不同" | 追 xrefs_to 找到来源 Sheet，确认后陈述 |
| "两边定义可能有差异" | 打开引用 Sheet 的计算逻辑，读懂再结论 |

### 查询命令

```bash
# 查某 cell 的公式和引用
python -c "
import json
d = json.load(open('{tag}_formula_export/formulas.json', encoding='utf-8'))
cell = d['{SheetName}']['{CellRef}']
print('formula:', cell['formula'])
print('value:', cell['value'])
print('refs_to:', cell['refs_to'])
print('xrefs_to:', cell['xrefs_to'])
"
```

> 只有在 formulas.json 不存在（未跑公式提取）且无法补跑时，才允许提假说——但 MUST 同时说明"尚未核查公式，以下为推测"。

---

## 九、跨区块血缘验证（读完所有 sheet 后自动执行）

> **核心思维模式**：同一业务概念（如"引入量"）在一个 Excel 里可能出现在多个区块/Sheet。人类大脑默认它们是连通的。AI 的任务是显式验证这个假设。

**触发时机**：所有选中 sheet 的 Step 1 数据提取完成后，自动执行（不需要用户提醒）。

**执行三步**（详见 `references/lineage_guidelines.md`）：

| 步骤 | 操作 | 输入 |
|------|------|------|
| Step 1：语义聚类 | 识别跨 sheet/区块的「语义等价组」（同一业务概念） | 各 sheet 的 data.md |
| Step 2：连通性验证 | 检查组内成员间是否存在公式引用链路 | formulas.json |
| Step 3：数值一致性比对 | 对无公式连通的区块对，做 99.9% 容差的数值相似度比对 | data.md 中的数值 |

**四象限分类结果**：

| 状态 | 符号 | 含义 |
|------|------|------|
| 公式连通 | 🟢 | 有引用链路，健康 |
| 疑似复制 | 🟡 | 无引用但数值 ≥95% 一致，更新时需手动同步 |
| 已发散 | 🔴 | 无引用且数值 <95% 一致，高风险，口径可能已分裂 |
| 无法判断 | ⚪ | 长度不同 / 数据稀疏，人工核查 |

**输出**：`{tag}_export/lineage_report.md`（独立文件，不写入 data.md）

> 详细算法、聚类规则、输出模板见 `references/lineage_guidelines.md`。

---

## 十、输出结构（下游 Skill 的消费接口）

**完整模式**：
```
{tag}_export/
├── sheet_mapping.json                    # sheet中文名 ↔ 目录名映射
├── lineage_report.md                     # 跨区块血缘验证报告（第九章，自动生成）
├── table_schema_summary.md               # 子表边界摘要（第七章，按需生成）
├── sheet_NN_data/
│   ├── data.md                           # ← 主输出，下游 Skill 从这里读
│   ├── sheet_NN_ranges.json              # 截图区域规划记录（供参考）
│   └── table_schema.json                 # 子表 Schema（第七章，按需生成）
└── images/
    └── sheet_NN/
        └── detail_N.png                  # 按需截图，补充 data.md 的视觉盲区

{tag}_formula_export/                     # 公式层（第六章，默认生成）
├── formulas.json                         # 每个 cell 的公式 + 值 + 引用链路
└── formula_summary.md                    # 硬编码常量表 + 跨 Sheet 引用表
```

**轻量模式**（无 images 目录和 ranges.json）：
```
{tag}_export/
├── sheet_mapping.json
├── lineage_report.md
└── sheet_NN_data/
    └── data.md                           # ← 主输出，下游 Skill 从这里读

{tag}_formula_export/
├── formulas.json
└── formula_summary.md
```

---

## 十一、下游 Skill 如何消费本 Skill 的输出

| 下游需求 | 读取内容 |
|---------|---------|
| 理解表格内容和结构 | `data.md` 中的 Markdown 表格 + 文本树 |
| 理解业务语义（废弃/待定/约束） | `data.md` 中的 `🤖[AI]` 标注 |
| 理解颜色/格式含义 | `data.md` 中的 `<font color>` / `<span style>` + `🤖[AI]` 说明 |
| 查看嵌入图片/复杂视觉区域 | `images/sheet_NN/detail_N.png` 截图 |
| 定位原始行号 | `data.md` 中的 `R{行号}|` 前缀 |
| 追溯公式血缘 / 口径定义 | `{tag}_formula_export/formulas.json` → refs_to / xrefs_to |
| 理解某列在子表中的语义名 | `sheet_NN_data/table_schema.json` → cell → 子表名 + 列头 |
| 验证跨区块数据一致性 | `{tag}_export/lineage_report.md` → 🟢🟡🔴⚪ 四象限分类 |

> data.md 内容格式规范详见 `references/enrichment_guidelines.md`。


