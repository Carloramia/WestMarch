---
name: game-balance-lab
description: Model game resource flows, combat, progression and probability; simulate balance and inspect game-mechanic exploits. Use for economy design, numerical experiments and bounded abuse analysis, not financial advice or unapproved live-service load testing.
---

# Game Balance Lab

Separate model assumptions, computed results and actual gameplay evidence.

## Modes

- Economy flows: read [economy modeling](references/economy-modeling/references/spec.json). Identify sources, pools, converters, sinks, caps, exchange friction and circular gain.
- Combat, growth, probability or balance calculations: read [numerical simulation](references/numerical-simulation/references/spec.json).
- Reward duplication, arbitrage, disconnected transactions, negative incentives and extreme inputs: read [mechanic exploit testing](references/exploit-testing/references/spec.json).

## Method

1. Define the question, units, horizon, target player segment and existing parameter ranges. Mark unknowns instead of inventing production values.
2. Establish a baseline and invariants such as conservation, caps, bounded rewards or idempotent claims.
3. Explain what each formula changes in the player experience. Use supplied targets; imported example win-rate or variance thresholds are not universal acceptance criteria.
4. For stochastic models, record the seed, distributions, sample count and sensitivity to assumptions. Run deterministic boundary cases before Monte Carlo.
5. Keep experiments bounded. The imported 30-second and iteration limits are starting budgets; adjust only to the task's justified needs. Never turn a hypothetical burst scenario into live traffic without authorization.
6. Report the largest risks first, with the calculation or reproduction path, estimated effect, limits and a testable mitigation. A simulated result is not a production measurement.

Missing shared configuration references in old specifications are not installed dependencies. Request project values or make explicitly labeled illustrative assumptions. Use config-table-gen only when an actual configuration-table deliverable is requested.
