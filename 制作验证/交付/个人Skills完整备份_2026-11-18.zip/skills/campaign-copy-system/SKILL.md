---
name: campaign-copy-system
description: Turn a commercial or promotional brief into brand-aligned copy and channel adaptations, including messaging hierarchy, rewrites, variants, and delivery checks. Use for campaign, product, social, landing-page, video, email, and platform copy; do not invent product claims, testimonials, prices, or legal approvals.
---

# Campaign copy system

Start from a brief, not from slogans.

## Workflow

1. Extract objective, audience, offer, proof, desired action, channel, mandatory content, prohibited claims, tone, length, deadline, and approval owner. Use `待确认` for missing facts that affect claims.
2. Build a message hierarchy: single-minded proposition, supporting reasons to believe, objections, and call to action.
3. Define or infer a provisional brand voice with explicit evidence. Separate durable voice traits from campaign mood.
4. Draft the master copy, then adapt it to each channel's reading context and constraints. Do not merely shorten the same paragraph.
5. Label creative variants by strategy, not by arbitrary adjectives. Keep the strongest default first.
6. Run factual and rights-sensitive statements through `$fact-copyright-check` when sources, quotations, comparisons, statistics, likenesses, trademarks, or third-party material are involved.

Use [the editable brief](assets/creative-brief-template.md) when the input is incomplete or the user wants a reusable intake document.

## Delivery

Return final-ready copy separately from rationale. Include a compact compliance table when there are mandatory phrases, limits, claims, or multiple channels. Never present unsupported marketing language as verified fact.

