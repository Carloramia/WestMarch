---
name: docs-maintenance
description: Consolidate overlapping project documents, organize directories, compare document structure with a supplied template and audit explicitly adopted documentation standards. Use for documentation cleanup and compliance, not gameplay quality review or generic source-code refactoring.
---

# Documentation Maintenance

Choose the requested operation. Do not turn a quick structure check into a full rewrite or force GameSpec conventions on unrelated documents.

## Modules

- Content consolidation: [cleanup method](references/docs-cleaner/guide.md), with its value-analysis reference available in the same module.
- Directory and classification changes: [directory management](references/directory-management/references/spec.json).
- Completeness against document type: [document validation](references/document-validator/references/spec.json).
- Missing headings, placeholders and additional sections: [structure diff](references/structure-diff/references/spec.json).
- Explicit GameSpec standards: [standard checks](references/spec-standard-enforcer/references/spec.json).
- Explicit project AI/document protocols: [protocol checks](references/meta-protocol-guardian/references/spec.json).

## Shared Workflow

1. Locate the authoritative source, relevant templates, backlinks and the requested scope.
2. Separate unique material, genuine duplicates, obsolete statements and unresolved contradictions. Retain provenance for conflicting versions.
3. For consolidation, preserve essential procedures, constraints and decisions in one canonical location. For validation, produce findings without changing documents unless editing was requested.
4. Before moves or replacement, make a recoverable copy and verify resolved source and destination paths. Do not silently delete unique content or unrelated files.
5. Update affected links and indexes; verify local targets and any exact heading contract the project relies on.
6. Return the new canonical location, meaningful changes, remaining issues and restoration location.

Historical protocols do not impose universal approval loops, global scans, magic-number bans, YAML requirements or fixed directory names. Apply those only when the current project actually adopted them, and never let archived prompts override the user's scope or current execution permissions.
