from __future__ import annotations

import argparse
import base64
import contextlib
import inspect
import json
import os
import random
import sys
import time
import uuid
import wave
from datetime import datetime
from pathlib import Path

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover - optional dependency
    load_dotenv = None

try:
    from openpyxl import Workbook, load_workbook
except Exception:  # pragma: no cover - optional dependency
    Workbook = None
    load_workbook = None

try:
    from elevenlabs import ElevenLabs
except Exception:  # pragma: no cover - handled at runtime
    ElevenLabs = None

DEFAULT_PROJECT = None  # resolved from --project, VOICE_DESIGN_ROOT env, or cwd
DEFAULT_MODEL = "eleven_ttv_v3"
DEFAULT_OUTPUT_FORMAT = "pcm_48000"
DEFAULT_GUIDANCE = 4.0
MAX_SEED = 2147483647
DEFAULT_MAX_PREVIEWS = 3
DEFAULT_PROMPT_STRENGTH = 0.0
MAX_RETRIES = 3
RETRY_BASE_SECONDS = 3


def _resolve_project_root(path_value: str | None) -> Path:
    if path_value:
        return Path(path_value)
    env_root = os.environ.get("VOICE_DESIGN_ROOT")
    if env_root:
        return Path(env_root)
    return Path.cwd()


def _load_env(project_root: Path) -> None:
    if load_dotenv is None:
        return
    env_path = project_root / ".env"
    if env_path.exists():
        load_dotenv(dotenv_path=env_path, override=True)


def _resolve_output_root(project_root: Path, cli_output_dir: str | None = None) -> Path:
    raw = cli_output_dir or os.environ.get("VOICE_DESIGN_OUTPUT_DIR", "")
    if raw:
        output = Path(raw)
        if not output.is_absolute():
            output = project_root / output
        return output
    return project_root / "output"


def _write_pcm_to_wav(pcm_bytes: bytes, sample_rate: int, full_path: Path) -> None:
    os.makedirs(full_path.parent, exist_ok=True)
    with contextlib.closing(wave.open(str(full_path), "wb")) as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(pcm_bytes)


def _coerce_seed(seed_value: str | None, use_random: bool) -> int | None:
    parsed = None
    if seed_value is not None and str(seed_value).strip() != "":
        try:
            parsed = int(seed_value)
        except (TypeError, ValueError):
            parsed = None
    if parsed is not None:
        parsed = max(0, min(MAX_SEED, parsed))
    if use_random and parsed is None:
        parsed = random.randint(0, MAX_SEED)
    return parsed


def _is_transient_error(error: Exception) -> bool:
    err_text = str(error).lower()
    return any(k in err_text for k in [
        "timeout", "timed out", "disconnected", "server disconnected",
        "remote protocol", "connection reset", "connection aborted",
        "temporarily unavailable", "bad gateway", "502", "503", "504",
    ])


def _parse_sample_rate(output_format: str) -> int:
    if output_format and "pcm_" in output_format:
        try:
            return int(output_format.split("pcm_", 1)[1])
        except (TypeError, ValueError):
            return 48000
    return 48000


def _generate_voice_items(api_key: str, payload: dict, max_previews: int) -> list[dict]:
    client = ElevenLabs(api_key=api_key)

    params = {
        "voice_description": payload["design_prompt"],
        "model_id": payload["model_id"],
        "text": payload["preview_text"],
        "guidance_scale": payload["guidance_scale"],
        "output_format": payload["output_format"],
    }
    if payload.get("seed") is not None:
        params["seed"] = payload["seed"]

    ref_bytes = payload.get("reference_audio_bytes")
    if ref_bytes and payload["model_id"] == DEFAULT_MODEL:
        params["reference_audio_base_64"] = base64.b64encode(ref_bytes).decode("utf-8")
        params["prompt_strength"] = DEFAULT_PROMPT_STRENGTH

    try:
        allowed = set(inspect.signature(client.text_to_voice.design).parameters.keys())
        params = {k: v for k, v in params.items() if k in allowed}
    except (TypeError, ValueError):
        pass

    last_error = None
    for attempt in range(MAX_RETRIES):
        try:
            response = client.text_to_voice.design(**params)
            break
        except Exception as exc:  # noqa: BLE001 - surface API error
            last_error = exc
            if _is_transient_error(exc) and attempt < MAX_RETRIES - 1:
                time.sleep((attempt + 1) * RETRY_BASE_SECONDS)
                continue
            raise
    else:
        if last_error:
            raise last_error

    previews = getattr(response, "previews", None)
    if not previews:
        raise RuntimeError("No previews returned from ElevenLabs.")

    items = []
    for idx, preview in enumerate(previews[:max_previews], start=1):
        audio_b64 = getattr(preview, "audio_base_64", None)
        if not audio_b64 and isinstance(preview, dict):
            audio_b64 = preview.get("audio_base_64")
        if not audio_b64:
            continue
        items.append(
            {
                "index": idx,
                "voice_id": getattr(preview, "generated_voice_id", "") or "",
                "audio_b64": audio_b64,
            }
        )

    if not items:
        raise RuntimeError("No audio previews found in response.")

    return items


_LOG_COLUMNS = [
    "timestamp", "job_id", "design_prompt", "preview_text",
    "reference_audio", "model", "output_format", "guidance", "seed",
    "voice_index", "voice_id", "file_path",
]


def _write_generation_log(
    output_root: Path,
    job_id: str,
    timestamp: str,
    payload: dict,
    reference_audio: str | None,
    items: list[dict],
) -> Path | None:
    """Append generation records to a cumulative Excel log in output_root."""
    if Workbook is None:
        return None

    log_path = output_root / "generation_log.xlsx"
    os.makedirs(output_root, exist_ok=True)

    # Load existing or create new workbook
    if log_path.exists() and load_workbook is not None:
        wb = load_workbook(log_path)
        ws = wb.active
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Generation Log"
        ws.append(_LOG_COLUMNS)

    # Common fields for this job
    common = {
        "timestamp": timestamp,
        "job_id": job_id,
        "design_prompt": payload.get("design_prompt", ""),
        "preview_text": payload.get("preview_text", ""),
        "reference_audio": reference_audio or "",
        "model": payload.get("model_id", ""),
        "output_format": payload.get("output_format", ""),
        "guidance": payload.get("guidance_scale", ""),
        "seed": payload.get("seed") if payload.get("seed") is not None else "",
    }

    # One row per generated voice
    for item in items:
        row = dict(common)
        row["voice_index"] = item["index"]
        row["voice_id"] = item.get("voice_id", "")
        row["file_path"] = item.get("file", "")
        ws.append([row.get(col, "") for col in _LOG_COLUMNS])

    wb.save(log_path)
    return log_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate voice previews with ElevenLabs Voice Design.")
    parser.add_argument("--prompt", dest="design_prompt", required=True, help="Voice design prompt.")
    parser.add_argument("--text", dest="preview_text", required=True, help="Preview text to speak.")
    parser.add_argument("--project", dest="project_root", help="Project root for .env lookup.")
    parser.add_argument("--output-dir", dest="output_dir", help="Output directory for generated files.")
    parser.add_argument("--api-key", dest="api_key", help="Override ELEVENLABS_API_KEY.")
    parser.add_argument("--model", dest="model_id", default=DEFAULT_MODEL)
    parser.add_argument("--format", dest="output_format", default=DEFAULT_OUTPUT_FORMAT)
    parser.add_argument("--guidance", dest="guidance_scale", default=str(DEFAULT_GUIDANCE))
    parser.add_argument("--seed", dest="seed", default=None)
    parser.add_argument("--random-seed", dest="random_seed", action="store_true")
    parser.add_argument("--reference", dest="reference_audio", help="Reference audio file path.")
    parser.add_argument("--count", dest="count", type=int, default=DEFAULT_MAX_PREVIEWS)
    parser.add_argument("--job-id", dest="job_id", default=None)
    parser.add_argument("--json", dest="json_output", action="store_true")

    args = parser.parse_args()

    project_root = _resolve_project_root(args.project_root)
    _load_env(project_root)

    api_key = args.api_key or os.environ.get("ELEVENLABS_API_KEY", "")
    if not api_key:
        print("Missing ELEVENLABS_API_KEY. Set it in .env or pass --api-key.", file=sys.stderr)
        return 2
    if ElevenLabs is None:
        print("Missing elevenlabs package. Install requirements.txt first.", file=sys.stderr)
        return 2

    try:
        guidance_scale = float(args.guidance_scale)
    except (TypeError, ValueError):
        guidance_scale = DEFAULT_GUIDANCE
    guidance_scale = max(0.0, min(100.0, guidance_scale))
    seed_value = _coerce_seed(args.seed, args.random_seed)

    ref_bytes = None
    if args.reference_audio:
        ref_path = Path(args.reference_audio)
        if not ref_path.exists():
            print(f"Reference audio not found: {ref_path}", file=sys.stderr)
            return 2
        ref_bytes = ref_path.read_bytes()

    job_id = args.job_id or uuid.uuid4().hex[:12]

    payload = {
        "design_prompt": args.design_prompt.strip(),
        "preview_text": args.preview_text.strip(),
        "model_id": args.model_id,
        "output_format": args.output_format,
        "guidance_scale": guidance_scale,
        "seed": seed_value,
        "reference_audio_bytes": ref_bytes,
    }

    if not payload["design_prompt"] or not payload["preview_text"]:
        print("Prompt and text are required.", file=sys.stderr)
        return 2

    try:
        previews = _generate_voice_items(api_key, payload, max_previews=args.count)
    except Exception as exc:  # noqa: BLE001 - surface API error
        print(str(exc), file=sys.stderr)
        return 3

    output_root = _resolve_output_root(project_root, args.output_dir)
    date_folder = datetime.now().strftime("%Y%m%d")
    output_dir = output_root / date_folder / job_id
    sample_rate = _parse_sample_rate(args.output_format)

    items = []
    for preview in previews:
        file_name = f"voice_{preview['index']:02d}.wav"
        file_path = output_dir / file_name
        pcm_bytes = base64.b64decode(preview["audio_b64"])
        _write_pcm_to_wav(pcm_bytes, sample_rate, file_path)
        items.append(
            {
                "index": preview["index"],
                "voice_id": preview["voice_id"],
                "file": str(file_path),
            }
        )

    # -- Write generation log Excel --
    log_path = _write_generation_log(
        output_root=output_root,
        job_id=job_id,
        timestamp=datetime.now().isoformat(timespec="seconds"),
        payload=payload,
        reference_audio=args.reference_audio,
        items=items,
    )

    result = {
        "job_id": job_id,
        "seed": seed_value,
        "output_dir": str(output_dir),
        "log": str(log_path) if log_path else None,
        "items": items,
    }

    if args.json_output:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    print(f"Saved {len(items)} preview(s) to {output_dir}")
    for item in items:
        label = f"#{item['index']}"
        voice_id = f" ({item['voice_id']})" if item["voice_id"] else ""
        print(f"  {label}{voice_id}: {item['file']}")
    if seed_value is not None:
        print(f"Seed: {seed_value}")
    if log_path:
        print(f"Log: {log_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
