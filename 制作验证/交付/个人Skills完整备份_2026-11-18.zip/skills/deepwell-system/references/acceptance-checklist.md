# Deepwell Acceptance Checklist

Use this checklist before calling a Deepwell phase ready for acceptance.

## Service

- Launcher works: `app\启动深井.cmd`.
- Health endpoint returns `{ ok: true }`.
- Harness is detected when AI features are expected.
- Logs have no new service errors beyond Node SQLite experimental warnings.

## Data

- Active and soft-deleted item counts are known before and after work.
- Soft-deleted rows are not restored or purged without explicit instruction.
- New write paths save user content before AI work.
- Invalid uploads or inputs do not create partial dirty records.
- Export and backup still work after schema changes.

## UI

- Desktop and narrow mobile widths have no horizontal overflow.
- Inventory and search cards preserve quick readability.
- User text and AI supplement are visibly distinct.
- Buttons that hide/delete/archive content require confirmation.
- Long content is folded or summarized in list views and expanded in detail views.

## Search And Relations

- Search results show why they matched.
- Long natural-language searches are decomposed into usable signals where possible.
- Association graph avoids dense all-edge rendering.
- Selected-node relations include concise reasons and scores.

## AI And Sources

- AI supplements do not duplicate the user original.
- External factual enrichment includes source links when available.
- AI and research results are marked unverified or pending manual review.

## Documentation

- `app/README.md` reflects current capabilities.
- The latest phase acceptance document reflects what was verified and what remains limited.
- Any downloaded GitHub references are documented with source, commit, purpose, and adoption status.
