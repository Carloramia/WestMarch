---
name: writing-polish
description: Edit existing prose for natural voice, clarity and concision, or polish in-game dialogue, descriptions and UI text under terminology and length constraints. Use for rewriting and removing formulaic AI style; not campaign strategy, fact verification or new screenplay structure.
---

# Writing Polish

Improve the supplied text without inventing facts or replacing the author's intent.

## Select a Mode

- Natural prose and de-formulaic editing: use the relevant examples in [the language-pattern guide](references/humanizer/guide.md). Treat them as diagnostic patterns, not a banned-word list or a reason to force casual phrasing.
- Game dialogue, item descriptions, announcements or UI copy: read [game copy rules](references/copywriting-polish/references/spec.json) for the relevant text type.

## Method

1. Identify audience, intended tone, required terminology and actual length limits. Preserve a deliberately formal or stylized voice.
2. Replace vague abstraction, repeated conclusions and promotional filler with specific wording already supported by the source.
3. Preserve names, numbers, citations, mechanics, claims and established character voice. Flag uncertainty rather than silently correcting canon.
4. For game text, keep state meaning, action labels, localization placeholders and truncation limits intact. Do not invent an ID convention or a text limit from a generic example.
5. Return a ready-to-use version. Explain changes briefly only when useful or requested; do not output a long diagnostic essay by default.

Use campaign-copy-system for a new commercial brief and channel strategy. Rights or factual verification is a distinct task; polishing does not establish truth or clearance.
